<?php

session_start();

require_once('php/CreateDb.php');
require_once('./php/component.php');


// create instance of Createdb class
$database = new CreateDb("Productdb", "Producttb");

if (isset($_POST['add'])) {
    /// print_r($_POST['product_id']);
    if (isset($_SESSION['cart'])) {

        $item_array_id = array_column($_SESSION['cart'], "product_id");

        if (in_array($_POST['product_id'], $item_array_id)) {
            echo "<script>alert('Ónin sebette bar eken..!')</script>";
            echo "<script>window.location = 'index.php'</script>";
        } else {

            $count = count($_SESSION['cart']);
            $item_array = array(
                'product_id' => $_POST['product_id']
            );

            $_SESSION['cart'][$count] = $item_array;
        }

    } else {

        $item_array = array(
            'product_id' => $_POST['product_id']
        );

        // Create new session variable
        $_SESSION['cart'][0] = $item_array;
        print_r($_SESSION['cart']);
    }
}


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/> <!--metatextblock--><title>Kompaniya
        «NEFT=SERVIS»</title>
    <meta name="description" content="Neft-Servis kompaniyası - neft hám gaz úskenelerin islep shıǵarıw hám jetkizip beriw"/>
    <meta property="og:url" content="https://oil-service.com"/>
    <meta property="og:title" content="Neft-Servis"/>
    <meta property="og:description" content=""/>
    <meta property="og:type" content="website"/>
    <meta property="og:image" content="https://static.tildacdn.com/tild3831-6364-4164-b438-393731636139/Group_11.svg"/>
    <link rel="canonical" href="index.php"><!--/metatextblock-->
    <meta name="format-detection" content="telephone=no"/>
    <meta http-equiv="x-dns-prefetch-control" content="on">
    <link rel="dns-prefetch" href="https://ws.tildacdn.com">
    <link rel="dns-prefetch" href="https://static.tildacdn.com">
    <link rel="shortcut icon" href="https://static.tildacdn.com/tild3965-6564-4630-a665-666634643534/Group_11.ico"
          type="image/x-icon"/>
    <link rel="apple-touch-icon" href="https://static.tildacdn.com/tild3933-6431-4730-b239-633434356234/Group_11.png">
    <link rel="apple-touch-icon" sizes="76x76"
          href="https://static.tildacdn.com/tild3933-6431-4730-b239-633434356234/Group_11.png">
    <link rel="apple-touch-icon" sizes="152x152"
          href="https://static.tildacdn.com/tild3933-6431-4730-b239-633434356234/Group_11.png">
    <link rel="apple-touch-startup-image"
          href="https://static.tildacdn.com/tild3933-6431-4730-b239-633434356234/Group_11.png">
    <meta name="msapplication-TileColor" content="#11295c">
    <meta name="msapplication-TileImage"
          content="https://static.tildacdn.com/tild3763-3363-4362-a239-386137633566/Group_11.png"><!-- Assets -->
    <script src="https://neo.tildacdn.com/js/tilda-fallback-1.0.min.js" charset="utf-8" async></script>
    <link rel="stylesheet" href="https://static.tildacdn.com/css/tilda-grid-3.0.min.css" type="text/css" media="all"
          onerror="this.loaderr='y';"/>
    <link rel="stylesheet" href="tilda-blocks-page18662443.min.css@t=1674485691.css" type="text/css" media="all"
          onerror="this.loaderr='y';"/>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&subset=latin,cyrillic"
          rel="stylesheet">
    <link rel="stylesheet" href="https://static.tildacdn.com/css/tilda-animation-2.0.min.css" type="text/css"
          media="all" onerror="this.loaderr='y';"/>
    <link rel="stylesheet" href="https://static.tildacdn.com/css/tilda-forms-1.0.min.css" type="text/css" media="all"
          onerror="this.loaderr='y';"/>
    <link rel="stylesheet" href="https://static.tildacdn.com/css/tilda-popup-1.1.min.css" type="text/css" media="print"
          onload="this.media='all';" onerror="this.loaderr='y';"/>
    <noscript>
        <link rel="stylesheet" href="https://static.tildacdn.com/css/tilda-popup-1.1.min.css" type="text/css"
              media="all"/>
    </noscript>
    <script type="text/javascript">(function (d) {
            if (!d.visibilityState) {
                var s = d.createElement('script');
                s.src = 'https://static.tildacdn.com/js/tilda-polyfill-1.0.min.js';
                d.getElementsByTagName('head')[0].appendChild(s);
            }
        })(document);

        function t_onReady(func) {
            if (document.readyState != 'loading') {
                func();
            } else {
                document.addEventListener('DOMContentLoaded', func);
            }
        }

        function t_onFuncLoad(funcName, okFunc, time) {
            if (typeof window[funcName] === 'function') {
                okFunc();
            } else {
                setTimeout(function () {
                    t_onFuncLoad(funcName, okFunc, time);
                }, (time || 100));
            }
        }

        function t396_initialScale(t) {
            var e = document.getElementById("rec" + t);
            if (e) {
                var r = e.querySelector(".t396__artboard");
                if (r) {
                    var a, i = document.documentElement.clientWidth, l = [],
                        d = r.getAttribute("data-artboard-screens");
                    if (d) {
                        d = d.split(",");
                        for (var o = 0; o < d.length; o++) l[o] = parseInt(d[o], 10)
                    } else l = [320, 480, 640, 960, 1200];
                    for (o = 0; o < l.length; o++) {
                        var n = l[o];
                        n <= i && (a = n)
                    }
                    var g = "edit" === window.allrecords.getAttribute("data-tilda-mode"),
                        u = "center" === t396_getFieldValue(r, "valign", a, l),
                        c = "grid" === t396_getFieldValue(r, "upscale", a, l),
                        t = t396_getFieldValue(r, "height_vh", a, l), f = t396_getFieldValue(r, "height", a, l),
                        e = !!window.opr && !!window.opr.addons || !!window.opera || -1 !== navigator.userAgent.indexOf(" OPR/");
                    if (!g && u && !c && !t && f && !e) {
                        for (var s = parseFloat((i / a).toFixed(3)), _ = [r, r.querySelector(".t396__carrier"), r.querySelector(".t396__filter")], o = 0; o < _.length; o++) _[o].style.height = parseInt(f, 10) * s + "px";
                        for (var h = r.querySelectorAll(".t396__elem"), o = 0; o < h.length; o++) h[o].style.zoom = s
                    }
                }
            }
        }

        function t396_getFieldValue(t, e, r, a) {
            var i = a[a.length - 1],
                l = r === i ? t.getAttribute("data-artboard-" + e) : t.getAttribute("data-artboard-" + e + "-res-" + r);
            if (!l) for (var d = 0; d < a.length; d++) {
                var o = a[d];
                if (!(o <= r) && (l = o === i ? t.getAttribute("data-artboard-" + e) : t.getAttribute("data-artboard-" + e + "-res-" + o))) break
            }
            return l
        }</script>
    <script src="https://static.tildacdn.com/js/jquery-1.10.2.min.js" charset="utf-8"
            onerror="this.loaderr='y';"></script>
    <script src="https://static.tildacdn.com/js/tilda-scripts-3.0.min.js" charset="utf-8" defer
            onerror="this.loaderr='y';"></script>
    <script src="tilda-blocks-page18662443.min.js@t=1674485691" charset="utf-8" async
            onerror="this.loaderr='y';"></script>
    <script src="https://static.tildacdn.com/js/lazyload-1.3.min.js" charset="utf-8" async
            onerror="this.loaderr='y';"></script>
    <script src="https://static.tildacdn.com/js/tilda-animation-2.0.min.js" charset="utf-8" async
            onerror="this.loaderr='y';"></script>
    <script src="https://static.tildacdn.com/js/tilda-zero-1.1.min.js" charset="utf-8" async
            onerror="this.loaderr='y';"></script>
    <script src="https://static.tildacdn.com/js/tilda-popup-1.0.min.js" charset="utf-8" async
            onerror="this.loaderr='y';"></script>
    <script src="https://static.tildacdn.com/js/tilda-animation-sbs-1.0.min.js" charset="utf-8" async
            onerror="this.loaderr='y';"></script>
    <script src="https://static.tildacdn.com/js/tilda-zero-scale-1.0.min.js" charset="utf-8" async
            onerror="this.loaderr='y';"></script>
    <script src="https://static.tildacdn.com/js/tilda-events-1.0.min.js" charset="utf-8" async
            onerror="this.loaderr='y';"></script>
    <script src="https://api-maps.yandex.ru/2.0/?load=package.standard,package.geoObjects&amp;lang=ru-RU"
            type="text/javascript"></script>
    <meta name="yandex-verification" content="093b4f78e206c0dc"/>
    <script type="text/javascript">window.dataLayer = window.dataLayer || [];</script>
    <script type="text/javascript">(function () {
            if ((/bot|google|yandex|baidu|bing|msn|duckduckbot|teoma|slurp|crawler|spider|robot|crawling|facebook/i.test(navigator.userAgent)) === false && typeof (sessionStorage) != 'undefined' && sessionStorage.getItem('visited') !== 'y' && document.visibilityState) {
                var style = document.createElement('style');
                style.type = 'text/css';
                style.innerHTML = '@media screen and (min-width: 980px) {.t-records {opacity: 0;}.t-records_animated {-webkit-transition: opacity ease-in-out .2s;-moz-transition: opacity ease-in-out .2s;-o-transition: opacity ease-in-out .2s;transition: opacity ease-in-out .2s;}.t-records.t-records_visible {opacity: 1;}}';
                document.getElementsByTagName('head')[0].appendChild(style);

                function t_setvisRecs() {
                    var alr = document.querySelectorAll('.t-records');
                    Array.prototype.forEach.call(alr, function (el) {
                        el.classList.add("t-records_animated");
                    });
                    setTimeout(function () {
                        Array.prototype.forEach.call(alr, function (el) {
                            el.classList.add("t-records_visible");
                        });
                        sessionStorage.setItem("visited", "y");
                    }, 400);
                }

                document.addEventListener('DOMContentLoaded', t_setvisRecs);
            }
        })();</script>
</head>
<body class="t-body" style="margin:0;"><!--allrecords-->
<div id="allrecords" class="t-records" data-hook="blocks-collection-content-node" data-tilda-project-id="3938943"
     data-tilda-page-id="18662443" data-tilda-formskey="d0a54d12236600744a0c64570fe2802c" data-tilda-lazy="yes"
     data-tilda-project-headcode="yes"><!--header-->
    <div id="t-header" class="t-records" data-hook="blocks-collection-content-node" data-tilda-project-id="3938943"
         data-tilda-page-id="18662491" data-tilda-page-alias="header"
         data-tilda-formskey="d0a54d12236600744a0c64570fe2802c" data-tilda-lazy="yes" data-tilda-project-headcode="yes">
        <div id="rec319031654" class="r t-rec" style=" " data-animationappear="off" data-record-type="396"><!-- T396 -->
            <style>#rec319031654 .t396__artboard {
                    min-height: 620px;
                    height: 100vh;
                    background-color: #11295c;
                }

                #rec319031654 .t396__filter {
                    min-height: 620px;
                    height: 100vh;
                }

                #rec319031654 .t396__carrier {
                    min-height: 620px;
                    height: 100vh;
                    background-position: center center;
                    background-attachment: scroll;
                    background-size: cover;
                    background-repeat: no-repeat;
                }

                @media screen and (max-width: 1199px) {
                    #rec319031654 .t396__artboard {
                    }

                    #rec319031654 .t396__filter {
                    }

                    #rec319031654 .t396__carrier {
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec319031654 .t396__artboard {
                    }

                    #rec319031654 .t396__filter {
                    }

                    #rec319031654 .t396__carrier {
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec319031654 .t396__artboard {
                    }

                    #rec319031654 .t396__filter {
                    }

                    #rec319031654 .t396__carrier {
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec319031654 .t396__artboard {
                        min-height: 640px;
                        height: 640px;
                    }

                    #rec319031654 .t396__filter {
                        min-height: 640px;
                        height: 640px;
                    }

                    #rec319031654 .t396__carrier {
                        min-height: 640px;
                        height: 640px;
                        background-attachment: scroll;
                    }
                }

                #rec319031654 .tn-elem[data-elem-id="1622021097683"] {
                    z-index: 4;
                    top: calc(50vh - 0px + 1px);
                    left: calc(50% - 50px + 0px);
                    width: 100px;
                }

                #rec319031654 .tn-elem[data-elem-id="1622021097683"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                }

                @media screen and (max-width: 959px) {
                }

                @media screen and (max-width: 639px) {
                    #rec319031654 .tn-elem[data-elem-id="1622021097683"] {
                        top: calc(50vh - 0px + 1px);
                        left: calc(50% - 50px + 0px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec319031654 .tn-elem[data-elem-id="1622021097683"] {
                        top: calc(50vh - 0px + -30px);
                        left: calc(50% - 50px + 0px);
                        width: 80px;
                    }
                }</style>
            <div class='t396'>
                <div class="t396__artboard" data-artboard-recid="319031654" data-artboard-screens="320,480,640,960,1200"
                     data-artboard-height="620" data-artboard-valign="center" data-artboard-height_vh="100"
                     data-artboard-upscale="grid" data-artboard-height-res-320="640"
                >
                    <div class="t396__carrier" data-artboard-recid="319031654"></div>
                    <div class="t396__filter" data-artboard-recid="319031654"></div>
                    <div class='t396__elem tn-elem tn-elem__3190316541622021097683' data-elem-id='1622021097683'
                         data-elem-type='image' data-field-top-value="1" data-field-left-value="0"
                         data-field-width-value="100" data-field-axisy-value="center" data-field-axisx-value="center"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-animate-mobile="y" data-animate-sbs-event="intoview"
                         data-animate-sbs-trg="1" data-animate-sbs-trgofst="0" data-animate-sbs-loop="loop"
                         data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':700,'mx':'0','my':'0','sx':'1','sy':'1','op':0,'ro':0,'bl':'0','ea':'','dt':'0'},{'ti':700,'mx':'0','my':'0','sx':'1','sy':'1','op':1,'ro':0,'bl':'0','ea':'','dt':'0'},{'ti':700,'mx':'0','my':'0','sx':'1','sy':'1','op':0,'ro':0,'bl':'0','ea':'','dt':'0'},{'ti':700,'mx':'0','my':'0','sx':'1','sy':'1','op':1,'ro':0,'bl':'0','ea':'','dt':'0'}]"
                         data-field-filewidth-value="40" data-field-fileheight-value="29"
                         data-field-top-res-320-value="-30" data-field-left-res-320-value="0"
                         data-field-width-res-320-value="80" data-field-top-res-480-value="1"
                         data-field-left-res-480-value="0"
                    >
                        <div class='tn-atom'><img class='tn-atom__img t-img'
                                                  data-original='https://static.tildacdn.com/tild6238-3039-4432-b733-376537376638/Group_11.svg'
                                                  imgfield='tn_img_1622021097683'></div>
                    </div>
                </div>
            </div>
            <script>t_onReady(function () {
                    t_onFuncLoad('t396_init', function () {
                        t396_init('319031654');
                    });
                });</script><!-- /T396 --></div>
        <div id="rec319033519" class="r t-rec" style=" " data-animationappear="off" data-record-type="131"><!-- T123 -->
            <div class="t123">
                <div class="t-container_100 ">
                    <div class="t-width t-width_100 ">

                        <style>
                            #rec319031654 {
                                position: fixed;
                                left: 0;
                                top: 0;
                                right: 0;
                                bottom: 0;
                                z-index: 100005;
                            }
                        </style>
                        <script>
                            $("body").css("overflow", "hidden");
                            $(document).ready(function () {
                                setTimeout(function () {
                                    $("#rec319031654").delay(350).fadeOut('slow');
                                    $("body").css("overflow", "auto");
                                    window.dispatchEvent(new Event('resize'));
                                }, 3000);
                            });
                            $(window).on('load', function () {
                                $("#rec319031654").delay(350).fadeOut('slow');
                                setTimeout(function () {
                                    $("body").css("overflow", "auto");
                                    window.dispatchEvent(new Event('resize'));
                                }, 400);
                            });
                        </script>


                    </div>
                </div>
            </div>
        </div>
        <div id="rec477571199" class="r t-rec" style=" " data-animationappear="off" data-record-type="131"><!-- T123 -->
            <div class="t123">
                <div class="t-container_100 ">
                    <div class="t-width t-width_100 ">

                        <meta name="yandex-verification" content="093b4f78e206c0dc"/>


                    </div>
                </div>
            </div>
        </div>
        <div id="rec301474642" class="r t-rec" style=" " data-animationappear="off" data-record-type="396"><!-- T396 -->
            <style>#rec301474642 .t396__artboard {
                    height: 97px;
                    overflow: visible;
                }

                #rec301474642 .t396__filter {
                    height: 97px;
                }

                #rec301474642 .t396__carrier {
                    height: 97px;
                    background-position: center center;
                    background-attachment: scroll;
                    background-size: cover;
                    background-repeat: no-repeat;
                }

                @media screen and (max-width: 1199px) {
                    #rec301474642 .t396__artboard {
                    }

                    #rec301474642 .t396__filter {
                    }

                    #rec301474642 .t396__carrier {
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301474642 .t396__artboard {
                    }

                    #rec301474642 .t396__filter {
                    }

                    #rec301474642 .t396__carrier {
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301474642 .t396__artboard {
                    }

                    #rec301474642 .t396__filter {
                    }

                    #rec301474642 .t396__carrier {
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301474642 .t396__artboard {
                        height: 67px;
                        height: 67px;
                    }

                    #rec301474642 .t396__filter {
                        height: 67px;
                        height: 67px;
                    }

                    #rec301474642 .t396__carrier {
                        height: 67px;
                        height: 67px;
                        background-attachment: scroll;
                    }
                }

                #rec301474642 .tn-elem[data-elem-id="1617837779567"] {
                    z-index: 2;
                    top: 33px;
                    left: calc(50% - 600px + 472px);
                    width: 257px;
                }

                #rec301474642 .tn-elem[data-elem-id="1617837779567"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301474642 .tn-elem[data-elem-id="1617837779567"] {
                        top: 33px;
                        left: calc(50% - 480px + 352px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301474642 .tn-elem[data-elem-id="1617837779567"] {
                        top: 33px;
                        left: calc(50% - 320px + 192px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301474642 .tn-elem[data-elem-id="1617837779567"] {
                        top: 33px;
                        left: calc(50% - 240px + 112px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301474642 .tn-elem[data-elem-id="1617837779567"] {
                        top: 22px;
                        left: calc(50% - 160px + 80px);
                        width: 160px;
                    }
                }

                #rec301474642 .tn-elem[data-elem-id="1617837956851"] {
                    z-index: 3;
                    top: calc(48.5px - 0px + 0px);
                    left: 122px;
                    width: 37px;
                }

                #rec301474642 .tn-elem[data-elem-id="1617837956851"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301474642 .tn-elem[data-elem-id="1617837956851"] {
                        top: calc(48.5px - 0px + 0px);
                        left: 15px;
                    }
                }

                @media screen and (max-width: 959px) {
                }

                @media screen and (max-width: 639px) {
                    #rec301474642 .tn-elem[data-elem-id="1617837956851"] {
                        top: calc(48.5px - 0px + 0px);
                        left: 13px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301474642 .tn-elem[data-elem-id="1617837956851"] {
                        top: calc(48.5px - 0px + -1px);
                        left: 20px;
                        width: 27px;
                    }
                }

                #rec301474642 .tn-elem[data-elem-id="1621935900263"] {
                    z-index: 1;
                    top: 0px;
                    left: 0px;
                    width: 100%;
                    height: 100%;
                }

                #rec301474642 .tn-elem[data-elem-id="1621935900263"] .tn-atom {
                    opacity: 0.85;
                    background-color: #11295c;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                }

                @media screen and (max-width: 959px) {
                }

                @media screen and (max-width: 639px) {
                }

                @media screen and (max-width: 479px) {
                }

                #rec301474642 .tn-elem[data-elem-id="1617838455239"] {
                    z-index: 5;
                    top: calc(48.5px - 0px + -1px);
                    left: calc(100% - 220px + -240px);
                    width: 220px;
                }

                #rec301474642 .tn-elem[data-elem-id="1617838455239"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301474642 .tn-elem[data-elem-id="1617838455239"] {
                        top: calc(48.5px - 0px + 3px);
                        left: calc(100% - 220px + -10px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301474642 .tn-elem[data-elem-id="1617838455239"] {
                        top: calc(48.5px - 0px + -7px);
                        left: calc(100% - 220px + 1780px);
                    }
                }

                @media screen and (max-width: 639px) {
                }

                @media screen and (max-width: 479px) {
                }

                #rec301474642 .tn-elem[data-elem-id="1617838182435"] {
                    z-index: 4;
                    top: calc(48.5px - 40.5px + 20px);
                    left: calc(100% - 248px + -213px);
                    width: 248px;
                    height: 81px;
                }

                #rec301474642 .tn-elem[data-elem-id="1617838182435"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301474642 .tn-elem[data-elem-id="1617838182435"] {
                        top: calc(48.5px - 40.5px + 22px);
                        left: calc(100% - 248px + 20px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301474642 .tn-elem[data-elem-id="1617838182435"] {
                        top: calc(48.5px - 40.5px + -1px);
                        left: calc(100% - 248px + 1820px);
                    }
                }

                @media screen and (max-width: 639px) {
                }

                @media screen and (max-width: 479px) {
                }

                #rec301474642 .tn-elem[data-elem-id="1645118179980"] {
                    z-index: 9;
                    top: 55px;
                    left: 1201px;
                    width: 20px;
                    height: 1px;
                }

                #rec301474642 .tn-elem[data-elem-id="1645118179980"] .tn-atom {
                    background-color: #ffffff;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179980"] {
                        top: -264px;
                        left: 1016px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179980"] {
                        top: -118px;
                        left: 566px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179980"] {
                        top: -127px;
                        left: 425px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179980"] {
                        top: -139px;
                        left: 269px;
                    }
                }

                #rec301474642 .tn-elem[data-elem-id="1645118179976"] {
                    color: #ffffff;
                    z-index: 8;
                    top: 35px;
                    left: 1236px;
                    width: 24px;
                }

                #rec301474642 .tn-elem[data-elem-id="1645118179976"] .tn-atom {
                    color: #ffffff;
                    font-size: 14px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179976"] {
                        top: -288px;
                        left: 1052px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179976"] {
                        top: -142px;
                        left: 604px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179976"] {
                        top: -151px;
                        left: 459px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179976"] {
                        top: -161px;
                        left: 304px;
                    }

                    #rec301474642 .tn-elem[data-elem-id="1645118179976"] .tn-atom {
                        font-size: 14px;
                    }
                }

                #rec301474642 .tn-elem[data-elem-id="1645118179972"] {
                    color: #ffffff;
                    z-index: 7;
                    top: 35px;
                    left: 1226px;
                    width: 14px;
                }

                #rec301474642 .tn-elem[data-elem-id="1645118179972"] .tn-atom {
                    color: #ffffff;
                    font-size: 14px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179972"] {
                        top: -288px;
                        left: 1042px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179972"] {
                        top: -142px;
                        left: 593px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179972"] {
                        top: -151px;
                        left: 449px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179972"] {
                        top: -161px;
                        left: 294px;
                    }

                    #rec301474642 .tn-elem[data-elem-id="1645118179972"] .tn-atom {
                        font-size: 14px;
                    }
                }

                #rec301474642 .tn-elem[data-elem-id="1645118179968"] {
                    color: #ffffff;
                    z-index: 6;
                    top: 35px;
                    left: 1200px;
                    width: 24px;
                }

                #rec301474642 .tn-elem[data-elem-id="1645118179968"] .tn-atom {
                    color: #ffffff;
                    font-size: 14px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    text-transform: uppercase;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179968"] {
                        top: -288px;
                        left: 1017px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179968"] {
                        top: -142px;
                        left: 567px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179968"] {
                        top: -151px;
                        left: 424px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301474642 .tn-elem[data-elem-id="1645118179968"] {
                        top: -161px;
                        left: 269px;
                    }

                    #rec301474642 .tn-elem[data-elem-id="1645118179968"] .tn-atom {
                        font-size: 14px;
                    }
                }</style>
            <div class='t396'>
                <div class="t396__artboard" data-artboard-recid="301474642" data-artboard-screens="320,480,640,960,1200"
                     data-artboard-height="97" data-artboard-valign="center" data-artboard-upscale="grid"
                     data-artboard-ovrflw="visible" data-artboard-height-res-320="67"
                >
                    <div class="t396__carrier" data-artboard-recid="301474642"></div>
                    <div class="t396__filter" data-artboard-recid="301474642"></div>
                    <div class='t396__elem tn-elem tn-elem__3014746421617837779567' data-elem-id='1617837779567'
                         data-elem-type='image' data-field-top-value="33" data-field-left-value="472"
                         data-field-width-value="257" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-filewidth-value="257"
                         data-field-fileheight-value="29" data-field-top-res-320-value="22"
                         data-field-left-res-320-value="80" data-field-width-res-320-value="160"
                         data-field-top-res-480-value="33" data-field-left-res-480-value="112"
                         data-field-top-res-640-value="33" data-field-left-res-640-value="192"
                         data-field-top-res-960-value="33" data-field-left-res-960-value="352"
                    ><a class='tn-atom' href="index.php"><img class='tn-atom__img t-img'
                                                               data-original='https://static.tildacdn.com/tild3132-3830-4935-b563-356164346233/Group_13.svg'
                                                               imgfield='tn_img_1617837779567'></a></div>
                    <div class='t396__elem tn-elem tn-elem__3014746421617837956851' data-elem-id='1617837956851'
                         data-elem-type='image' data-field-top-value="0" data-field-left-value="122"
                         data-field-width-value="37" data-field-axisy-value="center" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-filewidth-value="44"
                         data-field-fileheight-value="30" data-field-top-res-320-value="-1"
                         data-field-left-res-320-value="20" data-field-width-res-320-value="27"
                         data-field-container-res-320-value="window" data-field-top-res-480-value="0"
                         data-field-left-res-480-value="13" data-field-top-res-960-value="0"
                         data-field-left-res-960-value="15" data-field-container-res-960-value="grid"
                    ><a class='tn-atom' href="index.php#menuopen"><img class='tn-atom__img t-img'
                                                                        data-original='https://static.tildacdn.com/tild3633-3266-4533-b932-336436343430/photo.svg'
                                                                        imgfield='tn_img_1617837956851'></a></div>
                    <div class='t396__elem tn-elem tn-elem__3014746421621935900263' data-elem-id='1621935900263'
                         data-elem-type='shape' data-field-top-value="0" data-field-left-value="0"
                         data-field-height-value="100" data-field-width-value="100" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="%"
                         data-field-widthunits-value="%"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014746421617838455239' data-elem-id='1617838455239'
                         data-elem-type='image' data-field-top-value="-1" data-field-left-value="-240"
                         data-field-width-value="220" data-field-axisy-value="center" data-field-axisx-value="right"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-filewidth-value="212"
                         data-field-fileheight-value="41" data-field-top-res-640-value="-7"
                         data-field-left-res-640-value="1780" data-field-top-res-960-value="3"
                         data-field-left-res-960-value="-10" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><img class='tn-atom__img t-img'
                                                  data-original='https://static.tildacdn.com/tild3733-3034-4836-b733-656263643632/Rectangle_9.png'
                                                  imgfield='tn_img_1617838455239'></div>
                    </div>
                    <div class='t396__elem tn-elem searchinput tn-elem__3014746421617838182435'
                         data-elem-id='1617838182435' data-elem-type='html' data-field-top-value="20"
                         data-field-left-value="-213" data-field-height-value="81" data-field-width-value="248"
                         data-field-axisy-value="center" data-field-axisx-value="right"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value="px"
                         data-field-widthunits-value="px" data-field-top-res-640-value="-1"
                         data-field-left-res-640-value="1820" data-field-top-res-960-value="22"
                         data-field-left-res-960-value="20" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom tn-atom__html'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014746421645118179980' data-elem-id='1645118179980'
                         data-elem-type='shape' data-field-top-value="55" data-field-left-value="1201"
                         data-field-height-value="1" data-field-width-value="20" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px"
                         data-field-top-res-320-value="-139" data-field-left-res-320-value="269"
                         data-field-container-res-320-value="grid" data-field-top-res-480-value="-127"
                         data-field-left-res-480-value="425" data-field-top-res-640-value="-118"
                         data-field-left-res-640-value="566" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="-264" data-field-left-res-960-value="1016"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014746421645118179976' data-elem-id='1645118179976'
                         data-elem-type='text' data-field-top-value="35" data-field-left-value="1236"
                         data-field-width-value="24" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="-161"
                         data-field-left-res-320-value="304" data-field-container-res-320-value="grid"
                         data-field-top-res-480-value="-151" data-field-left-res-480-value="459"
                         data-field-container-res-480-value="grid" data-field-top-res-640-value="-142"
                         data-field-left-res-640-value="604" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="-288" data-field-left-res-960-value="1052"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="https://oil-service.com.ru/" style="color: inherit">EN</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014746421645118179972' data-elem-id='1645118179972'
                         data-elem-type='text' data-field-top-value="35" data-field-left-value="1226"
                         data-field-width-value="14" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="-161"
                         data-field-left-res-320-value="294" data-field-container-res-320-value="grid"
                         data-field-top-res-480-value="-151" data-field-left-res-480-value="449"
                         data-field-container-res-480-value="grid" data-field-top-res-640-value="-142"
                         data-field-left-res-640-value="593" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="-288" data-field-left-res-960-value="1042"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom' field='tn_text_1645118179972'>/</div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014746421645118179968' data-elem-id='1645118179968'
                         data-elem-type='text' data-field-top-value="35" data-field-left-value="1200"
                         data-field-width-value="24" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="-161"
                         data-field-left-res-320-value="269" data-field-container-res-320-value="grid"
                         data-field-top-res-480-value="-151" data-field-left-res-480-value="424"
                         data-field-container-res-480-value="grid" data-field-top-res-640-value="-142"
                         data-field-left-res-640-value="567" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="-288" data-field-left-res-960-value="1017"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom' field='tn_text_1645118179968'>Ru</div>
                    </div>
                </div>
            </div>
            <script>t_onReady(function () {
                    t_onFuncLoad('t396_init', function () {
                        t396_init('301474642');
                    });
                });</script><!-- /T396 --></div>
        <div id="rec301475246" class="r t-rec t-rec_pt_0 t-rec_pb_0" style="padding-top:0px;padding-bottom:0px; "
             data-animationappear="off" data-record-type="838"><!-- t838 --><!-- @classes: t-text -->
            <div class="t838">
                <div class="t-container">
                    <div class="t-col t-col_5">
                        <div class="t838__wrapper t-site-search-input">
                            <div class="t838__blockinput"><input type="text" class="t838__input t-input " placeholder=""
                                                                 data-search-target="all" style="color:#ffffff; ">
                                <svg role="img" class="t838__search-icon" xmlns="http://www.w3.org/2000/svg"
                                     viewBox="0 0 88 88">
                                    <path fill="#b6b6b6"
                                          d="M85 31.1c-.5-8.7-4.4-16.6-10.9-22.3C67.6 3 59.3 0 50.6.6c-8.7.5-16.7 4.4-22.5 11-11.2 12.7-10.7 31.7.6 43.9l-5.3 6.1-2.5-2.2-17.8 20 9 8.1 17.8-20.2-2.1-1.8 5.3-6.1c5.8 4.2 12.6 6.3 19.3 6.3 9 0 18-3.7 24.4-10.9 5.9-6.6 8.8-15 8.2-23.7zM72.4 50.8c-9.7 10.9-26.5 11.9-37.6 2.3-10.9-9.8-11.9-26.6-2.3-37.6 4.7-5.4 11.3-8.5 18.4-8.9h1.6c6.5 0 12.7 2.4 17.6 6.8 5.3 4.7 8.5 11.1 8.9 18.2.5 7-1.9 13.8-6.6 19.2z"/>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script>t_onReady(function () {
                    var tildaSearch = 'https://static.tilda' + 'cdn.com/js/tilda-search-';
                    if (!document.querySelector('script[src^="https://search.tildacdn.com/static/tilda-search-"]') && !document.querySelector('script[src^="' + tildaSearch + '"]')) {
                        var script = document.createElement('script');
                        script.src = tildaSearch + '1.2.min.js';
                        script.type = 'text/javascript';
                        document.body.appendChild(script);
                    }
                });</script>
            <style>#rec301475246 input::-webkit-input-placeholder {
                    color: #ffffff;
                    opacity: 0.5;
                }

                #rec301475246 input::-moz-placeholder {
                    color: #ffffff;
                    opacity: 0.5;
                }

                #rec301475246 input:-moz-placeholder {
                    color: #ffffff;
                    opacity: 0.5;
                }

                #rec301475246 input:-ms-input-placeholder {
                    color: #ffffff;
                    opacity: 0.5;
                }</style>
        </div>
        <div id="rec301475111" class="r t-rec" style=" " data-animationappear="off" data-record-type="131"><!-- T123 -->
            <div class="t123">
                <div class="t-container_100 ">
                    <div class="t-width t-width_100 ">

                        <style>
                            #rec301474642 {
                                width: 100%;
                                position: fixed;
                                top: 0px;
                                z-index: 9999;

                            }
                        </style>


                    </div>
                </div>
            </div>
        </div>
        <div id="rec301475215" class="r t-rec" style=" " data-animationappear="off" data-record-type="131"><!-- T123 -->
            <div class="t123">
                <div class="t-container_100 ">
                    <div class="t-width t-width_100 ">

                        <style>
                            .t838 .t-submit {
                                padding-left: 20px !important;
                                padding-right: 20px !important;
                                height: 40px !important;
                            }

                            .t838 .t-input {
                                height: 40px !important
                            }

                            .searchinput {
                                z-index: 200 !important
                            }
                        </style>
                        <script>
                            $(document).ready(function () {
                                $("#rec301475246").appendTo(".searchinput .tn-atom");
                            });
                        </script>


                    </div>
                </div>
            </div>
        </div>
        <div id="rec311931197" class="r t-rec" style=" " data-animationappear="off" data-record-type="396"><!-- T396 -->
            <style>#rec311931197 .t396__artboard {
                    min-height: 800px;
                    height: 100vh;
                }

                #rec311931197 .t396__filter {
                    min-height: 800px;
                    height: 100vh;
                }

                #rec311931197 .t396__carrier {
                    min-height: 800px;
                    height: 100vh;
                    background-position: center center;
                    background-attachment: scroll;
                    background-size: cover;
                    background-repeat: no-repeat;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .t396__artboard {
                    }

                    #rec311931197 .t396__filter {
                    }

                    #rec311931197 .t396__carrier {
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .t396__artboard {
                        min-height: 790px;
                        height: 790px;
                    }

                    #rec311931197 .t396__filter {
                        min-height: 790px;
                        height: 790px;
                    }

                    #rec311931197 .t396__carrier {
                        min-height: 790px;
                        height: 790px;
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .t396__artboard {
                    }

                    #rec311931197 .t396__filter {
                    }

                    #rec311931197 .t396__carrier {
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .t396__artboard {
                        min-height: 620px;
                        height: 620px;
                    }

                    #rec311931197 .t396__filter {
                        min-height: 620px;
                        height: 620px;
                    }

                    #rec311931197 .t396__carrier {
                        min-height: 620px;
                        height: 620px;
                        background-attachment: scroll;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620209939551"] {
                    z-index: 1;
                    top: 0px;
                    left: 0px;
                    width: 41%;
                    height: 100%;
                }

                #rec311931197 .tn-elem[data-elem-id="1620209939551"] .tn-atom {
                    opacity: 0.6;
                    background-color: #11295c;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620209939551"] {
                        top: 0px;
                        left: 0px;
                        width: 74%;
                        height: 100%;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620209939551"] {
                        top: -1px;
                        left: 0px;
                        width: 88%;
                        height: 100%;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620209939551"] {
                        top: -1px;
                        left: 0px;
                        width: 100%;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620209939551"] {
                        top: -1px;
                        left: 0px;
                        width: 100%;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620210087514"] {
                    color: #ffffff;
                    z-index: 2;
                    top: 142px;
                    left: 120px;
                    width: 460px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620210087514"] .tn-atom {
                    color: #ffffff;
                    font-size: 30px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210087514"] {
                        top: 70px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210087514"] {
                        top: 90px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210087514"] {
                        top: 110px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210087514"] {
                        top: 90px;
                        left: 10px;
                        width: 440px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1620210087514"] .tn-atom {
                        font-size: 22px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620210176285"] {
                    color: #ffffff;
                    z-index: 3;
                    top: 208px;
                    left: 120px;
                    width: 460px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620210176285"] .tn-atom {
                    color: #ffffff;
                    font-size: 30px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210176285"] {
                        top: 136px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210176285"] {
                        top: 156px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210176285"] {
                        top: 166px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210176285"] {
                        top: 136px;
                        left: 10px;
                        width: 440px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1620210176285"] .tn-atom {
                        font-size: 22px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620210216802"] {
                    color: #ffffff;
                    z-index: 4;
                    top: 274px;
                    left: 120px;
                    width: 460px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620210216802"] .tn-atom {
                    color: #ffffff;
                    font-size: 30px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210216802"] {
                        top: 202px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210216802"] {
                        top: 222px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210216802"] {
                        top: 223px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210216802"] {
                        top: 182px;
                        left: 10px;
                        width: 440px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1620210216802"] .tn-atom {
                        font-size: 22px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620210222809"] {
                    color: #ffffff;
                    z-index: 6;
                    top: 340px;
                    left: 120px;
                    width: 460px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620210222809"] .tn-atom {
                    color: #ffffff;
                    font-size: 30px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210222809"] {
                        top: 266px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210222809"] {
                        top: 287px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210222809"] {
                        top: 287px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210222809"] {
                        top: 233px;
                        left: 10px;
                        width: 440px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1620210222809"] .tn-atom {
                        font-size: 22px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620210222819"] {
                    color: #ffffff;
                    z-index: 7;
                    top: 409px;
                    left: 118px;
                    width: 460px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620210222819"] .tn-atom {
                    color: #ffffff;
                    font-size: 30px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210222819"] {
                        top: 332px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210222819"] {
                        top: 353px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210222819"] {
                        top: 343px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210222819"] {
                        top: 279px;
                        left: 10px;
                        width: 440px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1620210222819"] .tn-atom {
                        font-size: 22px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620210229201"] {
                    color: #ffffff;
                    z-index: 8;
                    top: 475px;
                    left: 120px;
                    width: 460px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620210229201"] .tn-atom {
                    color: #ffffff;
                    font-size: 30px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210229201"] {
                        top: 398px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210229201"] {
                        top: 419px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210229201"] {
                        top: 399px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620210229201"] {
                        top: 325px;
                        left: 10px;
                        width: 440px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1620210229201"] .tn-atom {
                        font-size: 22px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620294422732"] {
                    z-index: 13;
                    top: 50px;
                    left: 131px;
                    width: 3px;
                    height: 31px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620294422732"] .tn-atom {
                    border-radius: 30px;
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                #rec311931197 .tn-elem[data-elem-id="1620294422732"] .tn-atom {
                    -webkit-transform: rotate(45deg);
                    -moz-transform: rotate(45deg);
                    transform: rotate(45deg);
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620294422732"] {
                        top: 10px;
                        left: 22px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620294422732"] {
                        top: 18px;
                        left: 21px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620294422732"] {
                        top: 11px;
                        left: 21px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620294422732"] {
                        top: -1px;
                        left: 21px;
                        width: 2px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620294448147"] {
                    z-index: 14;
                    top: 50px;
                    left: 131px;
                    width: 3px;
                    height: 31px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620294448147"] .tn-atom {
                    border-radius: 30px;
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                #rec311931197 .tn-elem[data-elem-id="1620294448147"] .tn-atom {
                    -webkit-transform: rotate(135deg);
                    -moz-transform: rotate(135deg);
                    transform: rotate(135deg);
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620294448147"] {
                        top: 10px;
                        left: 22px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620294448147"] {
                        top: 18px;
                        left: 21px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620294448147"] {
                        top: 11px;
                        left: 21px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620294448147"] {
                        top: -1px;
                        left: 21px;
                        width: 2px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620295813672"] {
                    z-index: 15;
                    top: 187px;
                    left: 120px;
                    width: 191px;
                    height: 2px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620295813672"] .tn-atom {
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295813672"] {
                        top: 115px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295813672"] {
                        top: 135px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295813672"] {
                        top: 155px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295813672"] {
                        top: 125px;
                        left: 10px;
                        width: 140px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620295860456"] {
                    z-index: 16;
                    top: 253px;
                    left: 120px;
                    width: 120px;
                    height: 2px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620295860456"] .tn-atom {
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295860456"] {
                        top: 181px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295860456"] {
                        top: 201px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295860456"] {
                        top: 211px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295860456"] {
                        top: 171px;
                        left: 10px;
                        width: 90px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620295865815"] {
                    z-index: 17;
                    top: 319px;
                    left: 120px;
                    width: 135px;
                    height: 2px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620295865815"] .tn-atom {
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295865815"] {
                        top: 247px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295865815"] {
                        top: 267px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295865815"] {
                        top: 267px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295865815"] {
                        top: 217px;
                        left: 10px;
                        width: 97px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620295873399"] {
                    z-index: 19;
                    top: 386px;
                    left: 120px;
                    width: 230px;
                    height: 2px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620295873399"] .tn-atom {
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295873399"] {
                        top: 311px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295873399"] {
                        top: 332px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295873399"] {
                        top: 332px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295873399"] {
                        top: 268px;
                        left: 10px;
                        width: 168px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620295876913"] {
                    z-index: 20;
                    top: 454px;
                    left: 120px;
                    width: 150px;
                    height: 2px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620295876913"] .tn-atom {
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295876913"] {
                        top: 377px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295876913"] {
                        top: 398px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295876913"] {
                        top: 388px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295876913"] {
                        top: 314px;
                        left: 10px;
                        width: 113px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620295880092"] {
                    z-index: 21;
                    top: 520px;
                    left: 120px;
                    width: 145px;
                    height: 2px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620295880092"] .tn-atom {
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295880092"] {
                        top: 443px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295880092"] {
                        top: 464px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295880092"] {
                        top: 444px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620295880092"] {
                        top: 360px;
                        left: 10px;
                        width: 107px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1620369370381"] {
                    z-index: 22;
                    top: 47px;
                    left: 117px;
                    width: 31px;
                    height: 38px;
                }

                #rec311931197 .tn-elem[data-elem-id="1620369370381"] .tn-atom {
                    opacity: 0;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1620369370381"] {
                        top: 7px;
                        left: 8px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1620369370381"] {
                        top: 15px;
                        left: 7px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1620369370381"] {
                        top: 8px;
                        left: 7px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1620369370381"] {
                        top: -4px;
                        left: 7px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1621867520031"] {
                    color: #ffffff;
                    z-index: 23;
                    top: 640px;
                    left: 120px;
                    width: 450px;
                }

                #rec311931197 .tn-elem[data-elem-id="1621867520031"] .tn-atom {
                    color: #ffffff;
                    font-size: 20px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1621867520031"] {
                        top: 560px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1621867520031"] {
                        top: 585px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1621867520031"] {
                        top: 449px;
                        left: 10px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1621867520031"] .tn-atom {
                        font-size: 15px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1621867520055"] {
                    color: #ffffff;
                    z-index: 24;
                    top: 670px;
                    left: 120px;
                    width: 450px;
                }

                #rec311931197 .tn-elem[data-elem-id="1621867520055"] .tn-atom {
                    color: #ffffff;
                    font-size: 30px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1621867520055"] {
                        top: 591px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 959px) {
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1621867520055"] {
                        top: 619px;
                        left: 10px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1621867520055"] {
                        top: 475px;
                        left: 10px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1621867520055"] .tn-atom {
                        font-size: 22px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1629819146611"] {
                    color: #ffffff;
                    z-index: 27;
                    top: 775px;
                    left: 118px;
                    width: 24px;
                }

                #rec311931197 .tn-elem[data-elem-id="1629819146611"] .tn-atom {
                    color: #ffffff;
                    font-size: 14px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    text-transform: uppercase;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819146611"] {
                        top: 702px;
                        left: 11px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819146611"] {
                        top: 711px;
                        left: 12px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819146611"] {
                        top: 716px;
                        left: 11px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819146611"] {
                        top: 559px;
                        left: 10px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1629819146611"] .tn-atom {
                        font-size: 14px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1629819249404"] {
                    color: #ffffff;
                    z-index: 28;
                    top: 774px;
                    left: 145px;
                    width: 14px;
                }

                #rec311931197 .tn-elem[data-elem-id="1629819249404"] .tn-atom {
                    color: #ffffff;
                    font-size: 14px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819249404"] {
                        top: 702px;
                        left: 36px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819249404"] {
                        top: 711px;
                        left: 38px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819249404"] {
                        top: 716px;
                        left: 36px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819249404"] {
                        top: 559px;
                        left: 35px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1629819249404"] .tn-atom {
                        font-size: 14px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1629819286265"] {
                    color: #ffffff;
                    z-index: 29;
                    top: 775px;
                    left: 153px;
                    width: 24px;
                }

                #rec311931197 .tn-elem[data-elem-id="1629819286265"] .tn-atom {
                    color: #ffffff;
                    font-size: 14px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819286265"] {
                        top: 702px;
                        left: 46px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819286265"] {
                        top: 711px;
                        left: 49px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819286265"] {
                        top: 716px;
                        left: 46px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819286265"] {
                        top: 559px;
                        left: 45px;
                    }

                    #rec311931197 .tn-elem[data-elem-id="1629819286265"] .tn-atom {
                        font-size: 14px;
                    }
                }

                #rec311931197 .tn-elem[data-elem-id="1629819318718"] {
                    z-index: 30;
                    top: 797px;
                    left: 117px;
                    width: 20px;
                    height: 1px;
                }

                #rec311931197 .tn-elem[data-elem-id="1629819318718"] .tn-atom {
                    background-color: #ffffff;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819318718"] {
                        top: 726px;
                        left: 11px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819318718"] {
                        top: 735px;
                        left: 12px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819318718"] {
                        top: 740px;
                        left: 12px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec311931197 .tn-elem[data-elem-id="1629819318718"] {
                        top: 581px;
                        left: 11px;
                    }
                }</style>
            <div class='t396'>
                <div class="t396__artboard" data-artboard-recid="311931197" data-artboard-screens="320,480,640,960,1200"
                     data-artboard-height="800" data-artboard-valign="center" data-artboard-height_vh="100"
                     data-artboard-upscale="grid" data-artboard-height-res-320="620" data-artboard-height-res-640="790"
                >
                    <div class="t396__carrier" data-artboard-recid="311931197"></div>
                    <div class="t396__filter" data-artboard-recid="311931197"></div>
                    <div class='t396__elem tn-elem tn-elem-blur tn-elem__3119311971620209939551'
                         data-elem-id='1620209939551' data-elem-type='shape' data-field-top-value="0"
                         data-field-left-value="0" data-field-height-value="100" data-field-width-value="41"
                         data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="%"
                         data-field-widthunits-value="%" data-field-top-res-320-value="-1"
                         data-field-left-res-320-value="0" data-field-width-res-320-value="100"
                         data-field-top-res-480-value="-1" data-field-left-res-480-value="0"
                         data-field-width-res-480-value="100" data-field-top-res-640-value="-1"
                         data-field-left-res-640-value="0" data-field-height-res-640-value="100"
                         data-field-width-res-640-value="88" data-field-top-res-960-value="0"
                         data-field-left-res-960-value="0" data-field-height-res-960-value="100"
                         data-field-width-res-960-value="74"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620210087514' data-elem-id='1620210087514'
                         data-elem-type='text' data-field-top-value="142" data-field-left-value="120"
                         data-field-width-value="460" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="90"
                         data-field-left-res-320-value="10" data-field-width-res-320-value="440"
                         data-field-top-res-480-value="110" data-field-left-res-480-value="10"
                         data-field-top-res-640-value="90" data-field-left-res-640-value="10"
                         data-field-top-res-960-value="70" data-field-left-res-960-value="10"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="aboutus.html" style="color: inherit">О компании</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620210176285' data-elem-id='1620210176285'
                         data-elem-type='text' data-field-top-value="208" data-field-left-value="120"
                         data-field-width-value="460" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="136"
                         data-field-left-res-320-value="10" data-field-width-res-320-value="440"
                         data-field-top-res-480-value="166" data-field-left-res-480-value="10"
                         data-field-top-res-640-value="156" data-field-left-res-640-value="10"
                         data-field-top-res-960-value="136" data-field-left-res-960-value="10"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="catalog.php" style="color: inherit">Каталог</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620210216802' data-elem-id='1620210216802'
                         data-elem-type='text' data-field-top-value="274" data-field-left-value="120"
                         data-field-width-value="460" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="182"
                         data-field-left-res-320-value="10" data-field-width-res-320-value="440"
                         data-field-top-res-480-value="223" data-field-left-res-480-value="10"
                         data-field-top-res-640-value="222" data-field-left-res-640-value="10"
                         data-field-top-res-960-value="202" data-field-left-res-960-value="10"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="news.html" style="color: inherit">Новости</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620210222809' data-elem-id='1620210222809'
                         data-elem-type='text' data-field-top-value="340" data-field-left-value="120"
                         data-field-width-value="460" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="233"
                         data-field-left-res-320-value="10" data-field-width-res-320-value="440"
                         data-field-top-res-480-value="287" data-field-left-res-480-value="10"
                         data-field-top-res-640-value="287" data-field-left-res-640-value="10"
                         data-field-top-res-960-value="266" data-field-left-res-960-value="10"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="nasha-komanda.html" style="color: inherit">Наша команда</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620210222819' data-elem-id='1620210222819'
                         data-elem-type='text' data-field-top-value="409" data-field-left-value="118"
                         data-field-width-value="460" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="279"
                         data-field-left-res-320-value="10" data-field-width-res-320-value="440"
                         data-field-top-res-480-value="343" data-field-left-res-480-value="10"
                         data-field-top-res-640-value="353" data-field-left-res-640-value="10"
                         data-field-top-res-960-value="332" data-field-left-res-960-value="10"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="vacancy.html" style="color: inherit">Вакансии</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620210229201' data-elem-id='1620210229201'
                         data-elem-type='text' data-field-top-value="475" data-field-left-value="120"
                         data-field-width-value="460" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="325"
                         data-field-left-res-320-value="10" data-field-width-res-320-value="440"
                         data-field-top-res-480-value="399" data-field-left-res-480-value="10"
                         data-field-top-res-640-value="419" data-field-left-res-640-value="10"
                         data-field-top-res-960-value="398" data-field-left-res-960-value="10"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="contacts.html" style="color: inherit">Контакты</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620294422732' data-elem-id='1620294422732'
                         data-elem-type='shape' data-field-top-value="50" data-field-left-value="131"
                         data-field-height-value="31" data-field-width-value="3" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px"
                         data-field-top-res-320-value="-1" data-field-left-res-320-value="21"
                         data-field-width-res-320-value="2" data-field-top-res-480-value="11"
                         data-field-left-res-480-value="21" data-field-top-res-640-value="18"
                         data-field-left-res-640-value="21" data-field-top-res-960-value="10"
                         data-field-left-res-960-value="22" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620294448147' data-elem-id='1620294448147'
                         data-elem-type='shape' data-field-top-value="50" data-field-left-value="131"
                         data-field-height-value="31" data-field-width-value="3" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px"
                         data-field-top-res-320-value="-1" data-field-left-res-320-value="21"
                         data-field-width-res-320-value="2" data-field-top-res-480-value="11"
                         data-field-left-res-480-value="21" data-field-top-res-640-value="18"
                         data-field-left-res-640-value="21" data-field-top-res-960-value="10"
                         data-field-left-res-960-value="22" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620295813672' data-elem-id='1620295813672'
                         data-elem-type='shape' data-field-top-value="187" data-field-left-value="120"
                         data-field-height-value="2" data-field-width-value="191" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px" data-animate-mobile="y"
                         data-animate-sbs-event="hover" data-animate-sbs-trgels="1620210087514"
                         data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':0,'mx':'0','my':'0','sx':'1','sy':'1','op':0,'ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':'1','sy':'1','op':1,'ro':'0','bl':'0','ea':'','dt':'0'}]"
                         data-field-top-res-320-value="125" data-field-left-res-320-value="10"
                         data-field-width-res-320-value="140" data-field-top-res-480-value="155"
                         data-field-left-res-480-value="10" data-field-top-res-640-value="135"
                         data-field-left-res-640-value="10" data-field-top-res-960-value="115"
                         data-field-left-res-960-value="10" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620295860456' data-elem-id='1620295860456'
                         data-elem-type='shape' data-field-top-value="253" data-field-left-value="120"
                         data-field-height-value="2" data-field-width-value="120" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px" data-animate-mobile="y"
                         data-animate-sbs-event="hover" data-animate-sbs-trgels="1620210176285"
                         data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':0,'mx':'0','my':'0','sx':'1','sy':'1','op':0,'ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':'1','sy':'1','op':1,'ro':'0','bl':'0','ea':'','dt':'0'}]"
                         data-field-top-res-320-value="171" data-field-left-res-320-value="10"
                         data-field-width-res-320-value="90" data-field-top-res-480-value="211"
                         data-field-left-res-480-value="10" data-field-top-res-640-value="201"
                         data-field-left-res-640-value="10" data-field-top-res-960-value="181"
                         data-field-left-res-960-value="10" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620295865815' data-elem-id='1620295865815'
                         data-elem-type='shape' data-field-top-value="319" data-field-left-value="120"
                         data-field-height-value="2" data-field-width-value="135" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px" data-animate-mobile="y"
                         data-animate-sbs-event="hover" data-animate-sbs-trgels="1620210216802"
                         data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':0,'mx':'0','my':'0','sx':'1','sy':'1','op':0,'ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':'1','sy':'1','op':1,'ro':'0','bl':'0','ea':'','dt':'0'}]"
                         data-field-top-res-320-value="217" data-field-left-res-320-value="10"
                         data-field-width-res-320-value="97" data-field-top-res-480-value="267"
                         data-field-left-res-480-value="10" data-field-top-res-640-value="267"
                         data-field-left-res-640-value="10" data-field-top-res-960-value="247"
                         data-field-left-res-960-value="10" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620295873399' data-elem-id='1620295873399'
                         data-elem-type='shape' data-field-top-value="386" data-field-left-value="120"
                         data-field-height-value="2" data-field-width-value="230" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px" data-animate-mobile="y"
                         data-animate-sbs-event="hover" data-animate-sbs-trgels="1620210222809"
                         data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':0,'mx':'0','my':'0','sx':'1','sy':'1','op':0,'ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':'1','sy':'1','op':1,'ro':'0','bl':'0','ea':'','dt':'0'}]"
                         data-field-top-res-320-value="268" data-field-left-res-320-value="10"
                         data-field-width-res-320-value="168" data-field-top-res-480-value="332"
                         data-field-left-res-480-value="10" data-field-top-res-640-value="332"
                         data-field-left-res-640-value="10" data-field-top-res-960-value="311"
                         data-field-left-res-960-value="10" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620295876913' data-elem-id='1620295876913'
                         data-elem-type='shape' data-field-top-value="454" data-field-left-value="120"
                         data-field-height-value="2" data-field-width-value="150" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px" data-animate-mobile="y"
                         data-animate-sbs-event="hover" data-animate-sbs-trgels="1620210222819"
                         data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':0,'mx':'0','my':'0','sx':'1','sy':'1','op':0,'ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':'1','sy':'1','op':1,'ro':'0','bl':'0','ea':'','dt':'0'}]"
                         data-field-top-res-320-value="314" data-field-left-res-320-value="10"
                         data-field-width-res-320-value="113" data-field-top-res-480-value="388"
                         data-field-left-res-480-value="10" data-field-top-res-640-value="398"
                         data-field-left-res-640-value="10" data-field-top-res-960-value="377"
                         data-field-left-res-960-value="10" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971620295880092' data-elem-id='1620295880092'
                         data-elem-type='shape' data-field-top-value="520" data-field-left-value="120"
                         data-field-height-value="2" data-field-width-value="145" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px" data-animate-mobile="y"
                         data-animate-sbs-event="hover" data-animate-sbs-trgels="1620210229201"
                         data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':0,'mx':'0','my':'0','sx':'1','sy':'1','op':0,'ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':'1','sy':'1','op':1,'ro':'0','bl':'0','ea':'','dt':'0'}]"
                         data-field-top-res-320-value="360" data-field-left-res-320-value="10"
                         data-field-width-res-320-value="107" data-field-top-res-480-value="444"
                         data-field-left-res-480-value="10" data-field-top-res-640-value="464"
                         data-field-left-res-640-value="10" data-field-top-res-960-value="443"
                         data-field-left-res-960-value="10" data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem menu-close tn-elem__3119311971620369370381'
                         data-elem-id='1620369370381' data-elem-type='shape' data-field-top-value="47"
                         data-field-left-value="117" data-field-height-value="38" data-field-width-value="31"
                         data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px"
                         data-field-top-res-320-value="-4" data-field-left-res-320-value="7"
                         data-field-top-res-480-value="8" data-field-left-res-480-value="7"
                         data-field-top-res-640-value="15" data-field-left-res-640-value="7"
                         data-field-top-res-960-value="7" data-field-left-res-960-value="8"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971621867520031' data-elem-id='1621867520031'
                         data-elem-type='text' data-field-top-value="640" data-field-left-value="120"
                         data-field-width-value="450" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="449"
                         data-field-left-res-320-value="10" data-field-container-res-320-value="grid"
                         data-field-top-res-480-value="585" data-field-left-res-480-value="10"
                         data-field-container-res-480-value="grid" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="560" data-field-left-res-960-value="10"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom' field='tn_text_1621867520031'>zakaz@oil-service.com</div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971621867520055' data-elem-id='1621867520055'
                         data-elem-type='text' data-field-top-value="670" data-field-left-value="120"
                         data-field-width-value="450" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="475"
                         data-field-left-res-320-value="10" data-field-container-res-320-value="grid"
                         data-field-top-res-480-value="619" data-field-left-res-480-value="10"
                         data-field-container-res-480-value="grid" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="591" data-field-left-res-960-value="10"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="tel:+73512220025" style="color: inherit">+7 (351) 222-00-25</a>
                        </div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971629819146611' data-elem-id='1629819146611'
                         data-elem-type='text' data-field-top-value="775" data-field-left-value="118"
                         data-field-width-value="24" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="559"
                         data-field-left-res-320-value="10" data-field-container-res-320-value="grid"
                         data-field-top-res-480-value="716" data-field-left-res-480-value="11"
                         data-field-container-res-480-value="grid" data-field-top-res-640-value="711"
                         data-field-left-res-640-value="12" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="702" data-field-left-res-960-value="11"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="index.php" style="color: inherit">Ru</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971629819249404' data-elem-id='1629819249404'
                         data-elem-type='text' data-field-top-value="774" data-field-left-value="145"
                         data-field-width-value="14" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="559"
                         data-field-left-res-320-value="35" data-field-container-res-320-value="grid"
                         data-field-top-res-480-value="716" data-field-left-res-480-value="36"
                         data-field-container-res-480-value="grid" data-field-top-res-640-value="711"
                         data-field-left-res-640-value="38" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="702" data-field-left-res-960-value="36"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom' field='tn_text_1629819249404'>/</div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971629819286265' data-elem-id='1629819286265'
                         data-elem-type='text' data-field-top-value="775" data-field-left-value="153"
                         data-field-width-value="24" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="window" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="559"
                         data-field-left-res-320-value="45" data-field-container-res-320-value="grid"
                         data-field-top-res-480-value="716" data-field-left-res-480-value="46"
                         data-field-container-res-480-value="grid" data-field-top-res-640-value="711"
                         data-field-left-res-640-value="49" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="702" data-field-left-res-960-value="46"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'><a href="https://oil-service.com.ru/" style="color: inherit">EN</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3119311971629819318718' data-elem-id='1629819318718'
                         data-elem-type='shape' data-field-top-value="797" data-field-left-value="117"
                         data-field-height-value="1" data-field-width-value="20" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="window"
                         data-field-topunits-value="px" data-field-leftunits-value="px"
                         data-field-heightunits-value="px" data-field-widthunits-value="px"
                         data-field-top-res-320-value="581" data-field-left-res-320-value="11"
                         data-field-container-res-320-value="grid" data-field-top-res-480-value="740"
                         data-field-left-res-480-value="12" data-field-top-res-640-value="735"
                         data-field-left-res-640-value="12" data-field-container-res-640-value="grid"
                         data-field-top-res-960-value="726" data-field-left-res-960-value="11"
                         data-field-container-res-960-value="grid"
                    >
                        <div class='tn-atom'></div>
                    </div>
                </div>
            </div>
            <script>t_onReady(function () {
                    t_onFuncLoad('t396_init', function () {
                        t396_init('311931197');
                    });
                });</script><!-- /T396 --></div>
        <div id="rec319046083" class="r t-rec" style=" " data-animationappear="off" data-record-type="131"><!-- T123 -->
            <div class="t123">
                <div class="t-container_100 ">
                    <div class="t-width t-width_100 ">

                        <style>
                            .tn-elem__3119311971620209939551 {

                                -webkit-backdrop-filter: saturate(180%) blur(4px);
                                backdrop-filter: saturate(180%) blur(4px);
                            }
                        </style>


                    </div>
                </div>
            </div>
        </div>
        <div id="rec311937111" class="r t-rec" style=" " data-animationappear="off" data-record-type="131"><!-- T123 -->
            <div class="t123">
                <div class="t-container_100 ">
                    <div class="t-width t-width_100 ">

                        <style>
                            .shirina {
                                background: none !important;
                                right: 0 !important;
                                left: 0 !important;
                                margin: 0 !important;
                                transform: translateX(-30%) scale(1) !important;
                            }

                            .t-popup_show .t-popup__container.t-popup__container-static.shirina {
                                transform: translateX(0) scale(1) !important;
                            }

                            .parpadding {
                                padding: 0 !important;
                            }

                            .menu-close {
                                cursor: pointer;
                            }

                            #rec311937267 .t-popup__close {
                                display: none;
                            }
                        </style>
                        <script>
                            var ZeroPopID = '#rec311931197';
                            var PopWindID = '#rec311937267';
                            $(document).ready(function () {
                                $(PopWindID + " .t-popup__container").addClass("shirina").html($(ZeroPopID)).parent(".t-popup").addClass("parpadding");
                                $(ZeroPopID).delegate(".t-submit", "click", function () {
                                    setTimeout(function () {
                                        if ($(ZeroPopID + " .t-form").hasClass("js-send-form-success")) {
                                            $(PopWindID + " .t-popup__close").trigger("click");
                                        }
                                        ;
                                    }, 1000);
                                });


                                $('.menu-close').click(function (e) {
                                    $(PopWindID).find('.t-popup__close').click();
                                })

                            });
                        </script>


                    </div>
                </div>
            </div>
        </div>
        <div id="rec407048207" class="r t-rec" style=" " data-animationappear="off" data-record-type="875"><!-- t875 -->
            <script>t_onReady(function () {
                    t_onFuncLoad('t875_init', function () {
                        t875_init('407048207');
                    });
                });</script>
        </div>
        <div id="rec311937267" class="r t-rec" style=" " data-record-type="390">
            <div class="t390">
                <div class="t-popup" data-tooltip-hook="#menuopen"
                     role="dialog"
                     aria-modal="true"
                     tabindex="-1"
                     aria-label="Content Oriented Web" style="background-color: rgba(9,17,35,0.80);">
                    <div class="t-popup__container t-width t-width_100" style="background-color:#fbfbf9;">
                        <div class="t390__wrapper t-align_left">
                            <div class="t390__title t-heading t-heading_lg" style="">Content Oriented Web</div>
                        </div>
                    </div>
                    <div class="t-popup__close t-popup__block-close">
                        <button type="button" class="t-popup__close-wrapper t-popup__block-close-button"
                                aria-label="Закрыть диалог">
                            <svg role="presentation" class="t-popup__close-icon" width="23px" height="23px"
                                 viewBox="0 0 23 23" version="1.1" xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink">
                                <g stroke="none" stroke-width="1" fill="#fff" fill-rule="evenodd">
                                    <rect transform="translate(11.313708, 11.313708) rotate(-45.000000) translate(-11.313708, -11.313708) "
                                          x="10.3137085" y="-3.6862915" width="2" height="30"></rect>
                                    <rect transform="translate(11.313708, 11.313708) rotate(-315.000000) translate(-11.313708, -11.313708) "
                                          x="10.3137085" y="-3.6862915" width="2" height="30"></rect>
                                </g>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            <script type="text/javascript">t_onReady(function () {
                    var rec = document.querySelector('#rec311937267');
                    if (!rec) return;
                    rec.setAttribute('data-animationappear', 'off');
                    rec.style.opacity = 1;
                    t_onFuncLoad('t390_initPopup', function () {
                        t390_initPopup('311937267');
                    });
                });</script>
        </div>
    </div><!--/header-->
    <div id="rec301471333" class="r t-rec" style=" " data-animationappear="off" data-record-type="396"><!-- T396 -->
        <style>#rec301471333 .t396__artboard {
                min-height: 700px;
                height: 100vh;
                background-color: #ffffff;
            }

            #rec301471333 .t396__filter {
                min-height: 700px;
                height: 100vh;
                background-color: rgba(17, 41, 92, 0);
            }

            #rec301471333 .t396__carrier {
                min-height: 700px;
                height: 100vh;
                background-position: center center;
                background-attachment: scroll;
                background-image: url('https://static.tildacdn.com/tild3338-6565-4137-b865-316664386162/-/resize/20x/photo.png');
                background-size: cover;
                background-repeat: no-repeat;
            }

            @media screen and (max-width: 1199px) {
                #rec301471333 .t396__artboard {
                }

                #rec301471333 .t396__filter {
                }

                #rec301471333 .t396__carrier {
                    background-attachment: scroll;
                }
            }

            @media screen and (max-width: 959px) {
                #rec301471333 .t396__artboard {
                }

                #rec301471333 .t396__filter {
                }

                #rec301471333 .t396__carrier {
                    background-attachment: scroll;
                }
            }

            @media screen and (max-width: 639px) {
                #rec301471333 .t396__artboard {
                }

                #rec301471333 .t396__filter {
                }

                #rec301471333 .t396__carrier {
                    background-attachment: scroll;
                }
            }

            @media screen and (max-width: 479px) {
                #rec301471333 .t396__artboard {
                    min-height: 560px;
                    height: 560px;
                }

                #rec301471333 .t396__filter {
                    min-height: 560px;
                    height: 560px;
                }

                #rec301471333 .t396__carrier {
                    min-height: 560px;
                    height: 560px;
                    background-attachment: scroll;
                }
            }

            #rec301471333 .tn-elem[data-elem-id="1617835771892"] {
                color: #ffffff;
                text-align: center;
                z-index: 2;
                top: calc(50vh - 350px + 253px);
                left: calc(50% - 600px + 220px);
                width: 760px;
            }

            #rec301471333 .tn-elem[data-elem-id="1617835771892"] .tn-atom {
                color: #ffffff;
                font-size: 35px;
                font-family: 'Montserrat', Arial, sans-serif;
                line-height: 1.55;
                font-weight: 700;
                background-position: center center;
                border-color: transparent;
                border-style: solid;
            }

            @media screen and (max-width: 1199px) {
                #rec301471333 .tn-elem[data-elem-id="1617835771892"] {
                    top: calc(50vh - 350px + 253px);
                    left: calc(50% - 480px + 100px);
                }
            }

            @media screen and (max-width: 959px) {
                #rec301471333 .tn-elem[data-elem-id="1617835771892"] {
                    top: calc(50vh - 350px + 213px);
                    left: calc(50% - 320px + -60px);
                }

                #rec301471333 .tn-elem[data-elem-id="1617835771892"] .tn-atom {
                    font-size: 26px;
                }
            }

            @media screen and (max-width: 639px) {
                #rec301471333 .tn-elem[data-elem-id="1617835771892"] {
                    top: calc(50vh - 350px + 213px);
                    left: calc(50% - 240px + -140px);
                }

                #rec301471333 .tn-elem[data-elem-id="1617835771892"] .tn-atom {
                    font-size: 23px;
                }
            }

            @media screen and (max-width: 479px) {
                #rec301471333 .tn-elem[data-elem-id="1617835771892"] {
                    top: calc(115px);
                    left: calc(50% - 160px + 0px);
                    width: 320px;
                }

                #rec301471333 .tn-elem[data-elem-id="1617835771892"] .tn-atom {
                    font-size: 21px;
                }
            }

            #rec301471333 .tn-elem[data-elem-id="1617835890753"] {
                color: #ffffff;
                text-align: center;
                z-index: 3;
                top: calc(50vh - 350px + 465px);
                left: calc(50% - 600px + 460px);
                width: 290px;
                height: 55px;
            }

            #rec301471333 .tn-elem[data-elem-id="1617835890753"] .tn-atom {
                color: #ffffff;
                font-size: 16px;
                font-family: 'Montserrat', Arial, sans-serif;
                line-height: 1.55;
                font-weight: 700;
                border-width: 1px;
                border-radius: 30px;
                background-color: #ee9542;
                background-position: center center;
                border-color: transparent;
                border-style: solid;
                transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out, border-color 0.2s ease-in-out;
            }

            @media screen and (max-width: 1199px) {
                #rec301471333 .tn-elem[data-elem-id="1617835890753"] {
                    top: calc(50vh - 350px + 465px);
                    left: calc(50% - 480px + 335px);
                }
            }

            @media screen and (max-width: 959px) {
                #rec301471333 .tn-elem[data-elem-id="1617835890753"] {
                    top: calc(50vh - 350px + 425px);
                    left: calc(50% - 320px + 175px);
                }
            }

            @media screen and (max-width: 639px) {
                #rec301471333 .tn-elem[data-elem-id="1617835890753"] {
                    top: calc(50vh - 350px + 425px);
                    left: calc(50% - 240px + 95px);
                }
            }

            @media screen and (max-width: 479px) {
                #rec301471333 .tn-elem[data-elem-id="1617835890753"] {
                    top: calc(395px);
                    left: calc(50% - 160px + 10px);
                    width: 300px;
                    height: 55px;
                }
            }

            #rec301471333 .tn-elem[data-elem-id="1617835984366"] {
                color: #ffffff;
                text-align: center;
                z-index: 4;
                top: calc(50vh - 350px + 390px);
                left: calc(50% - 600px + 155px);
                width: 890px;
            }

            #rec301471333 .tn-elem[data-elem-id="1617835984366"] .tn-atom {
                color: #ffffff;
                font-size: 16px;
                font-family: 'Montserrat', Arial, sans-serif;
                line-height: 1.55;
                font-weight: 100;
                background-position: center center;
                border-color: transparent;
                border-style: solid;
            }

            @media screen and (max-width: 1199px) {
                #rec301471333 .tn-elem[data-elem-id="1617835984366"] {
                    top: calc(50vh - 350px + 390px);
                    left: calc(50% - 480px + 35px);
                }
            }

            @media screen and (max-width: 959px) {
                #rec301471333 .tn-elem[data-elem-id="1617835984366"] {
                    top: calc(50vh - 350px + 310px);
                    left: calc(50% - 320px + 115px);
                    width: 410px;
                }
            }

            @media screen and (max-width: 639px) {
                #rec301471333 .tn-elem[data-elem-id="1617835984366"] {
                    top: calc(50vh - 350px + 300px);
                    left: calc(50% - 240px + 35px);
                }
            }

            @media screen and (max-width: 479px) {
                #rec301471333 .tn-elem[data-elem-id="1617835984366"] {
                    top: calc(260px);
                    left: calc(50% - 160px + 20px);
                    width: 280px;
                }
            }

            #rec301471333 .tn-elem[data-elem-id="1621931392188"] {
                z-index: 1;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
            }

            #rec301471333 .tn-elem[data-elem-id="1621931392188"] .tn-atom {
                background-position: center center;
                border-color: transparent;
                border-style: solid;
            }

            @media screen and (max-width: 1199px) {
            }

            @media screen and (max-width: 959px) {
            }

            @media screen and (max-width: 639px) {
            }

            @media screen and (max-width: 479px) {
            }</style>
        <div class='t396'>
            <div class="t396__artboard" data-artboard-recid="301471333" data-artboard-screens="320,480,640,960,1200"
                 data-artboard-height="700" data-artboard-valign="center" data-artboard-height_vh="100"
                 data-artboard-upscale="grid" data-artboard-height-res-320="560"
            >
                <div class="t396__carrier t-bgimg" data-artboard-recid="301471333"
                     data-original="https://static.tildacdn.com/tild3338-6565-4137-b865-316664386162/photo.png"></div>
                <div class="t396__filter" data-artboard-recid="301471333"></div>
                <div class='t396__elem tn-elem tn-elem__3014713331617835771892' data-elem-id='1617835771892'
                     data-elem-type='text' data-field-top-value="253" data-field-left-value="220"
                     data-field-width-value="760" data-field-axisy-value="top" data-field-axisx-value="left"
                     data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px"
                     data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="115"
                     data-field-left-res-320-value="0" data-field-width-res-320-value="320"
                     data-field-top-res-480-value="213" data-field-left-res-480-value="-140"
                     data-field-top-res-640-value="213" data-field-left-res-640-value="-60"
                     data-field-top-res-960-value="253" data-field-left-res-960-value="100"
                >
                    <div class='tn-atom' field='tn_text_1617835771892'>ISLEP SHIǴARÍW HÁM JETKERIP BERIW <br>Neft hám gaz
                        Úskeneler <br></div>
                </div>
                <div class='t396__elem tn-elem tn-elem__3014713331617835890753' data-elem-id='1617835890753'
                     data-elem-type='button' data-field-top-value="465" data-field-left-value="460"
                     data-field-height-value="55" data-field-width-value="290" data-field-axisy-value="top"
                     data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px"
                     data-field-leftunits-value="px" data-field-heightunits-value="" data-field-widthunits-value=""
                     data-field-top-res-320-value="395" data-field-left-res-320-value="10"
                     data-field-height-res-320-value="55" data-field-width-res-320-value="300"
                     data-field-top-res-480-value="425" data-field-left-res-480-value="95"
                     data-field-top-res-640-value="425" data-field-left-res-640-value="175"
                     data-field-top-res-960-value="465" data-field-left-res-960-value="335"
                ><a class='tn-atom' href="catalog.php">BÁRLÍQ KATALOGTÍ KÓRIW</a></div>
                <div class='t396__elem tn-elem tn-elem__3014713331617835984366' data-elem-id='1617835984366'
                     data-elem-type='text' data-field-top-value="390" data-field-left-value="155"
                     data-field-width-value="890" data-field-axisy-value="top" data-field-axisx-value="left"
                     data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px"
                     data-field-heightunits-value="" data-field-widthunits-value="px" data-field-top-res-320-value="260"
                     data-field-left-res-320-value="20" data-field-width-res-320-value="280"
                     data-field-top-res-480-value="300" data-field-left-res-480-value="35"
                     data-field-top-res-640-value="310" data-field-left-res-640-value="115"
                     data-field-width-res-640-value="410" data-field-top-res-960-value="390"
                     data-field-left-res-960-value="35"
                >
                    <div class='tn-atom' field='tn_text_1617835984366'>20 jıldan artıq waqıt dawamında biz islep shıǵarıw hám jetkizip beriw menen shuǵıllanamız
                        gidravlik giltler hám ónimler
                    </div>
                </div>
                <div class='t396__elem tn-elem tn-elem__3014713331621931392188' data-elem-id='1621931392188'
                     data-elem-type='html' data-field-top-value="0" data-field-left-value="0"
                     data-field-height-value="100" data-field-width-value="100" data-field-axisy-value="top"
                     data-field-axisx-value="left" data-field-container-value="window" data-field-topunits-value="px"
                     data-field-leftunits-value="px" data-field-heightunits-value="%" data-field-widthunits-value="%"
                >
                    <div class='tn-atom tn-atom__html'>
                        <div id="videoBackground">
                            <video style="object-fit: cover; background-size: cover; width: 100%; height: 100%;"
                                   preload="auto" playsinline autoplay loop muted>
                                <source src="https://dl.dropboxusercontent.com/s/100o6iwagv7jl4s/oilservice3.m4v?dl=0"
                                        type="video/mp4">
                            </video>
                        </div>
                        <script>$(document).ready(() => {
                                let width = $(window).width();
                                let height = $(window).height();
                                $("#videoBackground")
                                    .width(width)
                                    .height(height);
                            });
                            $(window).resize(() => {
                                let width = $(window).width();
                                let height = $(window).height();
                                $("#videoBackground")
                                    .width(width)
                                    .height(height);
                            });</script>
                    </div>
                </div>
            </div>
        </div>
        <script>t_onReady(function () {
                t_onFuncLoad('t396_init', function () {
                    t396_init('301471333');
                });
            });</script><!-- /T396 --></div><!--footer-->
    <div id="t-footer" class="t-records" data-hook="blocks-collection-content-node" data-tilda-project-id="3938943"
         data-tilda-page-id="18662493" data-tilda-page-alias="footer"
         data-tilda-formskey="d0a54d12236600744a0c64570fe2802c" data-tilda-lazy="yes" data-tilda-project-headcode="yes">
        <div id="rec301472351" class="r t-rec" style=" " data-animationappear="off" data-record-type="396"><!-- T396 -->
            <style>#rec301472351 .t396__artboard {
                    height: 365px;
                    background-color: #ffffff;
                }

                #rec301472351 .t396__filter {
                    height: 365px;
                    background-image: -webkit-gradient(linear, left top, left bottom, from(rgba(17, 41, 92, 1)), to(rgba(6, 19, 47, 1)));
                    background-image: -webkit-linear-gradient(top, rgba(17, 41, 92, 1), rgba(6, 19, 47, 1));
                    background-image: linear-gradient(to bottom, rgba(17, 41, 92, 1), rgba(6, 19, 47, 1));
                    will-change: transform;
                }

                #rec301472351 .t396__carrier {
                    height: 365px;
                    background-position: center center;
                    background-attachment: scroll;
                    background-size: cover;
                    background-repeat: no-repeat;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .t396__artboard {
                    }

                    #rec301472351 .t396__filter {
                    }

                    #rec301472351 .t396__carrier {
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .t396__artboard {
                        height: 500px;
                        height: 500px;
                    }

                    #rec301472351 .t396__filter {
                        height: 500px;
                        height: 500px;
                    }

                    #rec301472351 .t396__carrier {
                        height: 500px;
                        height: 500px;
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .t396__artboard {
                        height: 500px;
                        height: 500px;
                    }

                    #rec301472351 .t396__filter {
                        height: 500px;
                        height: 500px;
                    }

                    #rec301472351 .t396__carrier {
                        height: 500px;
                        height: 500px;
                        background-attachment: scroll;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .t396__artboard {
                        height: 460px;
                        height: 460px;
                    }

                    #rec301472351 .t396__filter {
                        height: 460px;
                        height: 460px;
                    }

                    #rec301472351 .t396__carrier {
                        height: 460px;
                        height: 460px;
                        background-attachment: scroll;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617836317724"] {
                    z-index: 1;
                    top: 138px;
                    left: calc(50% - 600px + 30px);
                    width: 1140px;
                    height: 1px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617836317724"] .tn-atom {
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836317724"] {
                        top: 108px;
                        left: calc(50% - 480px + 10px);
                        width: 940px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836317724"] {
                        top: 108px;
                        left: calc(50% - 320px + 10px);
                        width: 620px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836317724"] {
                        top: 98px;
                        left: calc(50% - 240px + 10px);
                        width: 460px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836317724"] {
                        top: 98px;
                        left: calc(50% - 160px + 10px);
                        width: 300px;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617836402824"] {
                    z-index: 2;
                    top: 213px;
                    left: calc(50% - 600px + 30px);
                    width: 1140px;
                    height: 1px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617836402824"] .tn-atom {
                    background-color: #7a8fbb;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836402824"] {
                        top: 183px;
                        left: calc(50% - 480px + 10px);
                        width: 940px;
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836402824"] {
                        top: 183px;
                        left: calc(50% - 320px + 10px);
                        width: 620px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836402824"] {
                        top: 173px;
                        left: calc(50% - 240px + 10px);
                        width: 460px;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836402824"] {
                        top: 193px;
                        left: calc(50% - 160px + 10px);
                        width: 300px;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617836492870"] {
                    z-index: 3;
                    top: 166px;
                    left: calc(50% - 600px + 30px);
                    width: 31px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617836492870"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836492870"] {
                        top: 136px;
                        left: calc(50% - 480px + 10px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836492870"] {
                        top: 136px;
                        left: calc(50% - 320px + 80px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836492870"] {
                        top: 126px;
                        left: calc(50% - 240px + 20px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836492870"] {
                        top: 124px;
                        left: calc(50% - 160px + 75px);
                        width: 20px;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617836689756"] {
                    color: #7a8fbb;
                    z-index: 4;
                    top: 164px;
                    left: calc(50% - 600px + 80px);
                    width: 190px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617836689756"] .tn-atom {
                    color: #7a8fbb;
                    font-size: 16px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836689756"] {
                        top: 134px;
                        left: calc(50% - 480px + 60px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836689756"] {
                        top: 134px;
                        left: calc(50% - 320px + 130px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836689756"] {
                        top: 124px;
                        left: calc(50% - 240px + 70px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836689756"] {
                        top: 122px;
                        left: calc(50% - 160px + 105px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617836689756"] .tn-atom {
                        font-size: 12px;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617836767027"] {
                    z-index: 5;
                    top: 165px;
                    left: calc(50% - 600px + 310px);
                    width: 23px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617836767027"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836767027"] {
                        top: 135px;
                        left: calc(50% - 480px + 290px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836767027"] {
                        top: 135px;
                        left: calc(50% - 320px + 370px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836767027"] {
                        top: 125px;
                        left: calc(50% - 240px + 280px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836767027"] {
                        top: 152px;
                        left: calc(50% - 160px + 89px);
                        width: 18px;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617836916100"] {
                    color: #7a8fbb;
                    z-index: 6;
                    top: 164px;
                    left: calc(50% - 600px + 350px);
                    width: 190px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617836916100"] .tn-atom {
                    color: #7a8fbb;
                    font-size: 16px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836916100"] {
                        top: 134px;
                        left: calc(50% - 480px + 330px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836916100"] {
                        top: 134px;
                        left: calc(50% - 320px + 410px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836916100"] {
                        top: 124px;
                        left: calc(50% - 240px + 320px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836916100"] {
                        top: 152px;
                        left: calc(50% - 160px + 119px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617836916100"] .tn-atom {
                        font-size: 12px;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617836999636"] {
                    z-index: 8;
                    top: 505px;
                    left: calc(50% - 600px + 1310px);
                    width: 31px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617836999636"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836999636"] {
                        top: 490px;
                        left: calc(50% - 480px + 1040px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836999636"] {
                        top: 685px;
                        left: calc(50% - 320px + 140px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836999636"] {
                        top: 805px;
                        left: calc(50% - 240px + 170px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617836999636"] {
                        top: 625px;
                        left: calc(50% - 160px + 20px);
                        width: 28px;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617837080720"] {
                    color: #7a8fbb;
                    z-index: 9;
                    top: 230px;
                    left: calc(50% - 600px + 30px);
                    width: 400px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617837080720"] .tn-atom {
                    color: #7a8fbb;
                    font-size: 12px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617837080720"] {
                        top: 200px;
                        left: calc(50% - 480px + 10px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617837080720"] {
                        top: 433px;
                        left: calc(50% - 320px + 120px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617837080720"] {
                        text-align: center;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617837080720"] {
                        top: 423px;
                        left: calc(50% - 240px + 39px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617837080720"] {
                        text-align: center;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617837080720"] {
                        top: 387px;
                        left: calc(50% - 160px + -40px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617837080720"] {
                        text-align: center;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617839024632"] {
                    color: #7a8fbb;
                    z-index: 10;
                    top: 280px;
                    left: calc(50% - 600px + 30px);
                    width: 210px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617839024632"] .tn-atom {
                    color: #7a8fbb;
                    font-size: 12px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839024632"] {
                        top: 250px;
                        left: calc(50% - 480px + 10px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839024632"] {
                        top: 215px;
                        left: calc(50% - 320px + 217px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839024632"] {
                        top: 220px;
                        left: calc(50% - 240px + 134px);
                        width: 210px;
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839024632"] {
                        text-align: center;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839024632"] {
                        top: 221px;
                        left: calc(50% - 160px + 50px);
                        width: 220px;
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839024632"] {
                        text-align: center;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617839045117"] {
                    color: #7a8fbb;
                    z-index: 11;
                    top: 280px;
                    left: calc(50% - 600px + 350px);
                    width: 160px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617839045117"] .tn-atom {
                    color: #7a8fbb;
                    font-size: 12px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839045117"] {
                        top: 250px;
                        left: calc(50% - 480px + 257px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839045117"] {
                        top: 257px;
                        left: calc(50% - 320px + 242px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839045117"] {
                        top: 302px;
                        left: calc(50% - 240px + 164px);
                        width: 150px;
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839045117"] {
                        text-align: center;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839045117"] {
                        top: 249px;
                        left: calc(50% - 160px + 79px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839045117"] {
                        text-align: center;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617839065155"] {
                    color: #7a8fbb;
                    z-index: 12;
                    top: 280px;
                    left: calc(50% - 600px + 620px);
                    width: 160px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617839065155"] .tn-atom {
                    color: #7a8fbb;
                    font-size: 12px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839065155"] {
                        top: 250px;
                        left: calc(50% - 480px + 454px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839065155"] {
                        top: 299px;
                        left: calc(50% - 320px + 242px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839065155"] {
                        top: 260px;
                        left: calc(50% - 240px + 159px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839065155"] {
                        text-align: center;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839065155"] {
                        top: 277px;
                        left: calc(50% - 160px + 79px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839065155"] {
                        text-align: center;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617839085729"] {
                    color: #7a8fbb;
                    text-align: center;
                    z-index: 13;
                    top: 280px;
                    left: calc(50% - 600px + 890px);
                    width: 180px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617839085729"] .tn-atom {
                    color: #7a8fbb;
                    font-size: 12px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839085729"] {
                        top: 250px;
                        left: calc(50% - 480px + 651px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839085729"] {
                        top: 341px;
                        left: calc(50% - 320px + 232px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839085729"] {
                        top: 342px;
                        left: calc(50% - 240px + 149px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839085729"] {
                        text-align: center;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839085729"] {
                        top: 305px;
                        left: calc(50% - 160px + 69px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839085729"] {
                        text-align: center;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617839161636"] {
                    z-index: 14;
                    top: 270px;
                    left: calc(50% - 600px + 1133px);
                    width: 36px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617839161636"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839161636"] {
                        top: 240px;
                        left: calc(50% - 480px + 913px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839161636"] {
                        top: 29px;
                        left: calc(50% - 320px + 294px);
                        width: 53px;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839161636"] {
                        top: 35px;
                        left: calc(50% - 240px + 214px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839161636"] {
                        top: 36px;
                        left: calc(50% - 160px + 134px);
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617839188070"] {
                    color: #7a8fbb;
                    text-align: right;
                    z-index: 15;
                    top: 230px;
                    left: calc(50% - 600px + 990px);
                    width: 180px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617839188070"] .tn-atom {
                    color: #7a8fbb;
                    font-size: 12px;
                    font-family: 'Montserrat', Arial, sans-serif;
                    line-height: 1.55;
                    font-weight: 400;
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839188070"] {
                        top: 200px;
                        left: calc(50% - 480px + 770px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839188070"] {
                        top: 405px;
                        left: calc(50% - 320px + 230px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839188070"] {
                        text-align: center;
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839188070"] {
                        top: 393px;
                        left: calc(50% - 240px + 149px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839188070"] {
                        text-align: center;
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617839188070"] {
                        top: 355px;
                        left: calc(50% - 160px + 70px);
                    }

                    #rec301472351 .tn-elem[data-elem-id="1617839188070"] {
                        text-align: center;
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617895733899"] {
                    z-index: 16;
                    top: 277px;
                    left: calc(50% - 600px + 295px);
                    width: 1px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617895733899"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895733899"] {
                        top: 630px;
                        left: calc(50% - 480px + 256px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895733899"] {
                        top: 210px;
                        left: calc(50% - 320px + 819px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895733899"] {
                        top: 300px;
                        left: calc(50% - 240px + 950px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895733899"] {
                        top: 277px;
                        left: calc(50% - 160px + 565px);
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617895771727"] {
                    z-index: 17;
                    top: 277px;
                    left: calc(50% - 600px + 562px);
                    width: 1px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617895771727"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895771727"] {
                        top: 480px;
                        left: calc(50% - 480px + 563px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895771727"] {
                        top: 290px;
                        left: calc(50% - 320px + 820px);
                    }
                }

                @media screen and (max-width: 639px) {
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895771727"] {
                        top: 277px;
                        left: calc(50% - 160px + 832px);
                    }
                }

                #rec301472351 .tn-elem[data-elem-id="1617895779927"] {
                    z-index: 18;
                    top: 277px;
                    left: calc(50% - 600px + 829px);
                    width: 1px;
                }

                #rec301472351 .tn-elem[data-elem-id="1617895779927"] .tn-atom {
                    background-position: center center;
                    border-color: transparent;
                    border-style: solid;
                }

                @media screen and (max-width: 1199px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895779927"] {
                        top: 480px;
                        left: calc(50% - 480px + 830px);
                    }
                }

                @media screen and (max-width: 959px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895779927"] {
                        top: 260px;
                        left: calc(50% - 320px + 820px);
                    }
                }

                @media screen and (max-width: 639px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895779927"] {
                        top: 350px;
                        left: calc(50% - 240px + 950px);
                    }
                }

                @media screen and (max-width: 479px) {
                    #rec301472351 .tn-elem[data-elem-id="1617895779927"] {
                        top: 277px;
                        left: calc(50% - 160px + 1099px);
                    }
                }</style>
            <div class='t396'>
                <div class="t396__artboard" data-artboard-recid="301472351" data-artboard-screens="320,480,640,960,1200"
                     data-artboard-height="365" data-artboard-valign="center" data-artboard-upscale="grid"
                     data-artboard-height-res-320="460" data-artboard-height-res-480="500"
                     data-artboard-height-res-640="500"
                >
                    <div class="t396__carrier" data-artboard-recid="301472351"></div>
                    <div class="t396__filter" data-artboard-recid="301472351"></div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617836317724' data-elem-id='1617836317724'
                         data-elem-type='shape' data-field-top-value="138" data-field-left-value="30"
                         data-field-height-value="1" data-field-width-value="1140" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value="px"
                         data-field-widthunits-value="px" data-field-top-res-320-value="98"
                         data-field-left-res-320-value="10" data-field-width-res-320-value="300"
                         data-field-top-res-480-value="98" data-field-left-res-480-value="10"
                         data-field-width-res-480-value="460" data-field-top-res-640-value="108"
                         data-field-left-res-640-value="10" data-field-width-res-640-value="620"
                         data-field-top-res-960-value="108" data-field-left-res-960-value="10"
                         data-field-width-res-960-value="940"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617836402824' data-elem-id='1617836402824'
                         data-elem-type='shape' data-field-top-value="213" data-field-left-value="30"
                         data-field-height-value="1" data-field-width-value="1140" data-field-axisy-value="top"
                         data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value="px"
                         data-field-widthunits-value="px" data-field-top-res-320-value="193"
                         data-field-left-res-320-value="10" data-field-width-res-320-value="300"
                         data-field-top-res-480-value="173" data-field-left-res-480-value="10"
                         data-field-width-res-480-value="460" data-field-top-res-640-value="183"
                         data-field-left-res-640-value="10" data-field-width-res-640-value="620"
                         data-field-top-res-960-value="183" data-field-left-res-960-value="10"
                         data-field-width-res-960-value="940"
                    >
                        <div class='tn-atom'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617836492870' data-elem-id='1617836492870'
                         data-elem-type='image' data-field-top-value="166" data-field-left-value="30"
                         data-field-width-value="31" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-filewidth-value="29"
                         data-field-fileheight-value="19" data-field-top-res-320-value="124"
                         data-field-left-res-320-value="75" data-field-width-res-320-value="20"
                         data-field-top-res-480-value="126" data-field-left-res-480-value="20"
                         data-field-top-res-640-value="136" data-field-left-res-640-value="80"
                         data-field-top-res-960-value="136" data-field-left-res-960-value="10"
                    ><a class='tn-atom' href="mailto:zakaz@oil-service.com"><img class='tn-atom__img t-img'
                                                                                 data-original='https://static.tildacdn.com/tild3935-3830-4764-a663-326532303037/Vector.svg'
                                                                                 imgfield='tn_img_1617836492870'></a>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617836689756' data-elem-id='1617836689756'
                         data-elem-type='text' data-field-top-value="164" data-field-left-value="80"
                         data-field-width-value="190" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="122"
                         data-field-left-res-320-value="105" data-field-top-res-480-value="124"
                         data-field-left-res-480-value="70" data-field-top-res-640-value="134"
                         data-field-left-res-640-value="130" data-field-top-res-960-value="134"
                         data-field-left-res-960-value="60"
                    >
                        <div class='tn-atom'><a href="mailto:zakaz@oil-service.com" style="color: inherit">zakaz@oil-service.com</a>
                        </div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617836767027' data-elem-id='1617836767027'
                         data-elem-type='image' data-field-top-value="165" data-field-left-value="310"
                         data-field-width-value="23" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-filewidth-value="21"
                         data-field-fileheight-value="22" data-field-top-res-320-value="152"
                         data-field-left-res-320-value="89" data-field-width-res-320-value="18"
                         data-field-top-res-480-value="125" data-field-left-res-480-value="280"
                         data-field-top-res-640-value="135" data-field-left-res-640-value="370"
                         data-field-top-res-960-value="135" data-field-left-res-960-value="290"
                    ><a class='tn-atom' href="tel:+73512220025"><img class='tn-atom__img t-img'
                                                                     data-original='https://static.tildacdn.com/tild3963-3035-4464-b636-646533646232/Group.svg'
                                                                     imgfield='tn_img_1617836767027'></a></div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617836916100' data-elem-id='1617836916100'
                         data-elem-type='text' data-field-top-value="164" data-field-left-value="350"
                         data-field-width-value="190" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="152"
                         data-field-left-res-320-value="119" data-field-top-res-480-value="124"
                         data-field-left-res-480-value="320" data-field-top-res-640-value="134"
                         data-field-left-res-640-value="410" data-field-top-res-960-value="134"
                         data-field-left-res-960-value="330"
                    >
                        <div class='tn-atom'><a href="tel:+73512220025" style="color: inherit">+7 (351) 222-00-25</a>
                        </div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617836999636' data-elem-id='1617836999636'
                         data-elem-type='image' data-field-top-value="505" data-field-left-value="1310"
                         data-field-width-value="31" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-filewidth-value="25"
                         data-field-fileheight-value="25" data-field-top-res-320-value="625"
                         data-field-left-res-320-value="20" data-field-width-res-320-value="28"
                         data-field-top-res-480-value="805" data-field-left-res-480-value="170"
                         data-field-top-res-640-value="685" data-field-left-res-640-value="140"
                         data-field-top-res-960-value="490" data-field-left-res-960-value="1040"
                    ><a class='tn-atom' href="https://instagram.com/oil_service174"><img class='tn-atom__img t-img'
                                                                                         data-original='https://static.tildacdn.com/tild6132-3035-4836-b162-366662656337/Group_1.svg'
                                                                                         imgfield='tn_img_1617836999636'></a>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617837080720' data-elem-id='1617837080720'
                         data-elem-type='text' data-field-top-value="230" data-field-left-value="30"
                         data-field-width-value="400" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="387"
                         data-field-left-res-320-value="-40" data-field-top-res-480-value="423"
                         data-field-left-res-480-value="39" data-field-top-res-640-value="433"
                         data-field-left-res-640-value="120" data-field-top-res-960-value="200"
                         data-field-left-res-960-value="10"
                    >
                        <div class='tn-atom' field='tn_text_1617837080720'>© «Neft - Servis» 2022 Jıl. JSHJ
                        </div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617839024632' data-elem-id='1617839024632'
                         data-elem-type='text' data-field-top-value="280" data-field-left-value="30"
                         data-field-width-value="210" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="221"
                         data-field-left-res-320-value="50" data-field-width-res-320-value="220"
                         data-field-top-res-480-value="220" data-field-left-res-480-value="134"
                         data-field-width-res-480-value="210" data-field-top-res-640-value="215"
                         data-field-left-res-640-value="217" data-field-top-res-960-value="250"
                         data-field-left-res-960-value="10"
                    >
                        <div class='tn-atom'><a href="police.html" style="color: inherit">Sıyasıy
                                Qáwipsizlik</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617839045117' data-elem-id='1617839045117'
                         data-elem-type='text' data-field-top-value="280" data-field-left-value="350"
                         data-field-width-value="160" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="249"
                         data-field-left-res-320-value="79" data-field-top-res-480-value="302"
                         data-field-left-res-480-value="164" data-field-width-res-480-value="150"
                         data-field-top-res-640-value="257" data-field-left-res-640-value="242"
                         data-field-top-res-960-value="250" data-field-left-res-960-value="257"
                    >
                        <div class='tn-atom' field='tn_text_1617839045117'><a href="cookies.html"
                                                                              style="color:#7a8fbb !important;">
                                Cookies fayllardan faydalanıw</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617839065155' data-elem-id='1617839065155'
                         data-elem-type='text' data-field-top-value="280" data-field-left-value="620"
                         data-field-width-value="160" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="277"
                         data-field-left-res-320-value="79" data-field-top-res-480-value="260"
                         data-field-left-res-480-value="159" data-field-top-res-640-value="299"
                         data-field-left-res-640-value="242" data-field-top-res-960-value="250"
                         data-field-left-res-960-value="454"
                    >
                        <div class='tn-atom' field='tn_text_1617839065155'><a href="usloviya-ispolzovaniya.html"
                                                                              style="color: rgb(122, 143, 187);">Paydalanıw SHártleri</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617839085729' data-elem-id='1617839085729'
                         data-elem-type='text' data-field-top-value="280" data-field-left-value="890"
                         data-field-width-value="180" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="305"
                         data-field-left-res-320-value="69" data-field-top-res-480-value="342"
                         data-field-left-res-480-value="149" data-field-top-res-640-value="341"
                         data-field-left-res-640-value="232" data-field-top-res-960-value="250"
                         data-field-left-res-960-value="651"
                    >
                        <div class='tn-atom'><a href="yuridicheskaya-informatsiya.html" style="color: inherit">
                                Kompaniya Rekvezitları</a></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617839161636' data-elem-id='1617839161636'
                         data-elem-type='image' data-field-top-value="270" data-field-left-value="1133"
                         data-field-width-value="36" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-filewidth-value="53"
                         data-field-fileheight-value="37" data-field-top-res-320-value="36"
                         data-field-left-res-320-value="134" data-field-top-res-480-value="35"
                         data-field-left-res-480-value="214" data-field-top-res-640-value="29"
                         data-field-left-res-640-value="294" data-field-width-res-640-value="53"
                         data-field-top-res-960-value="240" data-field-left-res-960-value="913"
                    ><a class='tn-atom' href="index.php"><img class='tn-atom__img t-img'
                                                               data-original='https://static.tildacdn.com/tild3030-3730-4433-b234-376366643762/Group_12.svg'
                                                               imgfield='tn_img_1617839161636'></a></div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617839188070' data-elem-id='1617839188070'
                         data-elem-type='text' data-field-top-value="230" data-field-left-value="990"
                         data-field-width-value="180" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-top-res-320-value="355"
                         data-field-left-res-320-value="70" data-field-top-res-480-value="393"
                         data-field-left-res-480-value="149" data-field-top-res-640-value="405"
                         data-field-left-res-640-value="230" data-field-top-res-960-value="200"
                         data-field-left-res-960-value="770"
                    >
                        <div class='tn-atom' field='tn_text_1617839188070'>Qaraqalpaqstan</div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617895733899' data-elem-id='1617895733899'
                         data-elem-type='image' data-field-top-value="277" data-field-left-value="295"
                         data-field-width-value="1" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-fileheight-value="23"
                         data-field-top-res-320-value="277" data-field-left-res-320-value="565"
                         data-field-top-res-480-value="300" data-field-left-res-480-value="950"
                         data-field-top-res-640-value="210" data-field-left-res-640-value="819"
                         data-field-top-res-960-value="630" data-field-left-res-960-value="256"
                    >
                        <div class='tn-atom'><img class='tn-atom__img t-img'
                                                  data-original='https://static.tildacdn.com/tild3335-3963-4632-b138-393466636661/Line_2.svg'
                                                  imgfield='tn_img_1617895733899'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617895771727' data-elem-id='1617895771727'
                         data-elem-type='image' data-field-top-value="277" data-field-left-value="562"
                         data-field-width-value="1" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-fileheight-value="23"
                         data-field-top-res-320-value="277" data-field-left-res-320-value="832"
                         data-field-top-res-640-value="290" data-field-left-res-640-value="820"
                         data-field-top-res-960-value="480" data-field-left-res-960-value="563"
                    >
                        <div class='tn-atom'><img class='tn-atom__img t-img'
                                                  data-original='https://static.tildacdn.com/tild3335-3963-4632-b138-393466636661/Line_2.svg'
                                                  imgfield='tn_img_1617895771727'></div>
                    </div>
                    <div class='t396__elem tn-elem tn-elem__3014723511617895779927' data-elem-id='1617895779927'
                         data-elem-type='image' data-field-top-value="277" data-field-left-value="829"
                         data-field-width-value="1" data-field-axisy-value="top" data-field-axisx-value="left"
                         data-field-container-value="grid" data-field-topunits-value="px"
                         data-field-leftunits-value="px" data-field-heightunits-value=""
                         data-field-widthunits-value="px" data-field-fileheight-value="23"
                         data-field-top-res-320-value="277" data-field-left-res-320-value="1099"
                         data-field-top-res-480-value="350" data-field-left-res-480-value="950"
                         data-field-top-res-640-value="260" data-field-left-res-640-value="820"
                         data-field-top-res-960-value="480" data-field-left-res-960-value="830"
                    >
                        <div class='tn-atom'><img class='tn-atom__img t-img'
                                                  data-original='https://static.tildacdn.com/tild3335-3963-4632-b138-393466636661/Line_2.svg'
                                                  imgfield='tn_img_1617895779927'></div>
                    </div>
                </div>
            </div>
            <script>t_onReady(function () {
                    t_onFuncLoad('t396_init', function () {
                        t396_init('301472351');
                    });
                });</script><!-- /T396 --></div>
    </div><!--/footer--></div><!--/allrecords--><!-- Stat --><!-- Yandex.Metrika counter 89220234 -->
<script type="text/javascript" data-tilda-cookie-type="analytics"> setTimeout(function () {
        (function (m, e, t, r, i, k, a) {
            m[i] = m[i] || function () {
                (m[i].a = m[i].a || []).push(arguments)
            };
            m[i].l = 1 * new Date();
            k = e.createElement(t), a = e.getElementsByTagName(t)[0], k.async = 1, k.src = r, a.parentNode.insertBefore(k, a)
        })(window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
        window.mainMetrikaId = 89220234;
        ym(window.mainMetrikaId, "init", {
            clickmap: true,
            trackLinks: true,
            accurateTrackBounce: true,
            webvisor: true,
            ecommerce: "dataLayer"
        });
    }, 2000);</script>
<noscript>
    <div><img src="https://mc.yandex.ru/watch/89220234" style="position:absolute; left:-9999px;" alt=""/></div>
</noscript> <!-- /Yandex.Metrika counter -->
<script type="text/javascript">if (!window.mainTracker) {
        window.mainTracker = 'tilda';
    }
    setTimeout(function () {
        (function (d, w, k, o, g) {
            var n = d.getElementsByTagName(o)[0], s = d.createElement(o), f = function () {
                n.parentNode.insertBefore(s, n);
            };
            s.type = "text/javascript";
            s.async = true;
            s.key = k;
            s.id = "tildastatscript";
            s.src = g;
            if (w.opera == "[object Opera]") {
                d.addEventListener("DOMContentLoaded", f, false);
            } else {
                f();
            }
        })(document, window, '0ceb22866f565e82a337630ffefae252', 'script', 'https://static.tildacdn.com/js/tilda-stat-1.0.min.js');
    }, 2000); </script>
</body>
</html>

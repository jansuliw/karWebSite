# Advance_Shopping_cart
Advanced Shopping Cart Tutorial With Php and MySqli Database

Before you execute this project make sure you insert values in the database.
to insert values in the database just type this command.

```sql
"INSERT INTO Producttb (product_name, product_price, product_image)
        VALUES ('Apple MacBook Pro',1799,'./upload/product1.png'),
                        ('Sony E7 Headphones',147,'./upload/product2.png'),
                        ('Sony Xperia Z4',459,'./upload/product3.png'),
                        ('Samsung Galaxy A50',278,'./upload/product4.png')";
```

Ones you insert these values just execute your application.
that's it.

Thank you.
